import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  predictions: defineTable({
    userId: v.id("users"),
    type: v.union(v.literal("image"), v.literal("symptoms")),
    imageStorageId: v.optional(v.id("_storage")),
    symptoms: v.optional(v.array(v.string())),
    prediction: v.string(),
    confidence: v.number(),
    recommendations: v.array(v.string()),
    timestamp: v.number(),
  }).index("by_user", ["userId"]),
  
  symptomProfiles: defineTable({
    symptoms: v.array(v.string()),
    disease: v.string(),
    severity: v.union(v.literal("mild"), v.literal("moderate"), v.literal("severe")),
    description: v.string(),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
