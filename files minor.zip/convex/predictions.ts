import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const savePrediction = mutation({
  args: {
    type: v.union(v.literal("image"), v.literal("symptoms")),
    imageStorageId: v.optional(v.id("_storage")),
    symptoms: v.optional(v.array(v.string())),
    prediction: v.string(),
    confidence: v.number(),
    recommendations: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    return await ctx.db.insert("predictions", {
      userId,
      type: args.type,
      imageStorageId: args.imageStorageId,
      symptoms: args.symptoms,
      prediction: args.prediction,
      confidence: args.confidence,
      recommendations: args.recommendations,
      timestamp: Date.now(),
    });
  },
});

export const getUserPredictions = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const predictions = await ctx.db
      .query("predictions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(20);

    return Promise.all(
      predictions.map(async (prediction) => ({
        ...prediction,
        imageUrl: prediction.imageStorageId
          ? await ctx.storage.getUrl(prediction.imageStorageId)
          : null,
      }))
    );
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});
