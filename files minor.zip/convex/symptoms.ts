import { v } from "convex/values";
import { query, mutation } from "./_generated/server";

// Enhanced symptom-based disease detection logic
const symptomDatabase = [
  {
    disease: "Pneumonia",
    symptoms: ["cough", "fever", "chest_pain", "shortness_of_breath", "fatigue", "chills", "rapid_breathing"],
    severity: "moderate",
    description: "Bacterial or viral infection causing inflammation in lung air sacs",
    treatment: "Antibiotics for bacterial pneumonia, supportive care for viral",
    urgency: "Seek medical attention within 24 hours"
  },
  {
    disease: "COVID-19",
    symptoms: ["dry_cough", "fever", "shortness_of_breath", "loss_of_taste", "fatigue", "body_aches", "sore_throat", "headache"],
    severity: "moderate",
    description: "Viral infection affecting respiratory system caused by SARS-CoV-2",
    treatment: "Supportive care, isolation, antiviral medications in severe cases",
    urgency: "Monitor symptoms, seek care if breathing difficulties develop"
  },
  {
    disease: "Tuberculosis",
    symptoms: ["persistent_cough", "night_sweats", "weight_loss", "chest_pain", "fatigue", "blood_in_sputum", "loss_of_appetite"],
    severity: "severe",
    description: "Bacterial infection primarily affecting lungs caused by Mycobacterium tuberculosis",
    treatment: "Long-term antibiotic therapy (6-9 months)",
    urgency: "Immediate medical evaluation and isolation required"
  },
  {
    disease: "Lung Cancer",
    symptoms: ["persistent_cough", "chest_pain", "shortness_of_breath", "weight_loss", "blood_in_sputum", "hoarseness", "bone_pain"],
    severity: "severe",
    description: "Malignant tumor in lung tissue, often related to smoking",
    treatment: "Surgery, chemotherapy, radiation therapy, targeted therapy",
    urgency: "Urgent oncology consultation required"
  },
  {
    disease: "Pulmonary Fibrosis",
    symptoms: ["shortness_of_breath", "dry_cough", "fatigue", "chest_discomfort", "clubbing_of_fingers", "rapid_shallow_breathing"],
    severity: "severe",
    description: "Progressive scarring and thickening of lung tissue",
    treatment: "Anti-fibrotic medications, oxygen therapy, lung transplant in severe cases",
    urgency: "Pulmonology consultation needed"
  },
  {
    disease: "Asthma",
    symptoms: ["wheezing", "shortness_of_breath", "chest_tightness", "cough", "difficulty_sleeping"],
    severity: "mild",
    description: "Chronic condition causing airway inflammation and narrowing",
    treatment: "Bronchodilators, inhaled corticosteroids, trigger avoidance",
    urgency: "Regular monitoring, emergency care for severe attacks"
  },
  {
    disease: "Chronic Obstructive Pulmonary Disease (COPD)",
    symptoms: ["chronic_cough", "shortness_of_breath", "wheezing", "chest_tightness", "frequent_respiratory_infections", "fatigue"],
    severity: "moderate",
    description: "Progressive lung disease including emphysema and chronic bronchitis",
    treatment: "Bronchodilators, inhaled steroids, oxygen therapy, pulmonary rehabilitation",
    urgency: "Regular pulmonology follow-up required"
  },
  {
    disease: "Pulmonary Embolism",
    symptoms: ["sudden_shortness_of_breath", "chest_pain", "rapid_heart_rate", "coughing_up_blood", "leg_swelling", "dizziness"],
    severity: "severe",
    description: "Blood clot blocking pulmonary arteries",
    treatment: "Anticoagulants, thrombolytics, surgical intervention in severe cases",
    urgency: "Medical emergency - seek immediate care"
  },
  {
    disease: "Pleural Effusion",
    symptoms: ["shortness_of_breath", "chest_pain", "dry_cough", "fever", "difficulty_lying_flat"],
    severity: "moderate",
    description: "Excess fluid accumulation around the lungs",
    treatment: "Treat underlying cause, thoracentesis if needed",
    urgency: "Medical evaluation within 24-48 hours"
  },
  {
    disease: "Pneumothorax",
    symptoms: ["sudden_chest_pain", "shortness_of_breath", "rapid_heart_rate", "fatigue", "bluish_skin"],
    severity: "severe",
    description: "Collapsed lung due to air in pleural space",
    treatment: "Chest tube insertion, surgery for recurrent cases",
    urgency: "Emergency medical attention required"
  },
  {
    disease: "Bronchitis",
    symptoms: ["persistent_cough", "mucus_production", "shortness_of_breath", "chest_discomfort", "fatigue", "low_grade_fever"],
    severity: "mild",
    description: "Inflammation of bronchial tubes, acute or chronic",
    treatment: "Rest, fluids, cough suppressants, bronchodilators if needed",
    urgency: "Monitor symptoms, seek care if worsening"
  },
  {
    disease: "Interstitial Lung Disease",
    symptoms: ["dry_cough", "shortness_of_breath", "fatigue", "weight_loss", "clubbing_of_fingers", "joint_pain"],
    severity: "severe",
    description: "Group of disorders causing lung scarring and inflammation",
    treatment: "Corticosteroids, immunosuppressants, oxygen therapy",
    urgency: "Specialist evaluation required"
  },
  {
    disease: "Sarcoidosis",
    symptoms: ["dry_cough", "shortness_of_breath", "chest_pain", "fatigue", "weight_loss", "skin_rashes"],
    severity: "moderate",
    description: "Inflammatory disease affecting multiple organs, commonly lungs",
    treatment: "Corticosteroids, immunosuppressive medications",
    urgency: "Rheumatology or pulmonology consultation"
  }
];

export const analyzeSymptoms = query({
  args: {
    symptoms: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const userSymptoms = args.symptoms.map(s => s.toLowerCase().replace(/\s+/g, '_'));
    
    // Calculate match scores for each disease
    const diseaseScores = symptomDatabase.map(disease => {
      const matchingSymptoms = disease.symptoms.filter(symptom => 
        userSymptoms.includes(symptom)
      );
      
      const score = matchingSymptoms.length / disease.symptoms.length;
      
      return {
        disease: disease.disease,
        score,
        matchingSymptoms: matchingSymptoms.length,
        totalSymptoms: disease.symptoms.length,
        severity: disease.severity,
        description: disease.description,
        treatment: disease.treatment,
        urgency: disease.urgency,
        confidence: Math.round(score * 100)
      };
    });

    // Sort by score and return top matches
    const sortedResults = diseaseScores
      .filter(result => result.score > 0.15) // Lower threshold for more results
      .sort((a, b) => b.score - a.score)
      .slice(0, 5); // Show top 5 results

    // Generate enhanced recommendations based on top result
    const recommendations = [];
    if (sortedResults.length > 0) {
      const topResult = sortedResults[0];
      
      // Add urgency-based recommendations
      recommendations.push(topResult.urgency);
      
      if (topResult.confidence > 70) {
        recommendations.push("High confidence match - prioritize medical consultation");
        recommendations.push("Bring this analysis and symptom list to your healthcare provider");
      } else if (topResult.confidence > 50) {
        recommendations.push("Moderate confidence - schedule medical appointment soon");
        recommendations.push("Monitor symptoms closely and seek care if they worsen");
      } else if (topResult.confidence > 30) {
        recommendations.push("Low-moderate confidence - consider medical evaluation");
        recommendations.push("Keep detailed symptom diary for healthcare provider");
      } else {
        recommendations.push("Keep track of symptoms and their progression");
        recommendations.push("Consult healthcare provider if symptoms persist or worsen");
      }

      // Add severity-based recommendations
      if (topResult.severity === "severe") {
        recommendations.unshift("⚠️ URGENT: Seek immediate medical attention");
      } else if (topResult.severity === "moderate") {
        recommendations.push("Schedule medical appointment within 1-2 days");
      }

      // Add specific disease recommendations
      if (topResult.disease.includes("Embolism") || topResult.disease.includes("Pneumothorax")) {
        recommendations.unshift("🚨 EMERGENCY: Call 911 or go to emergency room immediately");
      }
    } else {
      recommendations.push("No strong matches found for your symptoms");
      recommendations.push("Consider general medical consultation if symptoms persist");
      recommendations.push("Monitor symptoms and seek care if they worsen or new symptoms develop");
    }

    return {
      results: sortedResults,
      recommendations,
      hasHighRiskSymptoms: sortedResults.some(r => r.severity === "severe" && r.confidence > 40),
      hasEmergencySymptoms: sortedResults.some(r => 
        (r.disease.includes("Embolism") || r.disease.includes("Pneumothorax")) && r.confidence > 30
      ),
      totalMatches: sortedResults.length,
      analysisTimestamp: Date.now()
    };
  },
});

export const getAvailableSymptoms = query({
  args: {},
  handler: async () => {
    const allSymptoms = new Set();
    symptomDatabase.forEach(disease => {
      disease.symptoms.forEach(symptom => {
        allSymptoms.add(symptom.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()));
      });
    });
    
    return Array.from(allSymptoms).sort();
  },
});

export const getDiseaseInfo = query({
  args: {
    diseaseName: v.string(),
  },
  handler: async (ctx, args) => {
    const disease = symptomDatabase.find(d => d.disease === args.diseaseName);
    return disease || null;
  },
});

export const getSymptomStatistics = query({
  args: {},
  handler: async () => {
    const stats = {
      totalDiseases: symptomDatabase.length,
      severityBreakdown: {
        mild: symptomDatabase.filter(d => d.severity === "mild").length,
        moderate: symptomDatabase.filter(d => d.severity === "moderate").length,
        severe: symptomDatabase.filter(d => d.severity === "severe").length,
      },
      totalSymptoms: new Set(symptomDatabase.flatMap(d => d.symptoms)).size,
      mostCommonSymptoms: getMostCommonSymptoms(),
    };
    return stats;
  },
});

function getMostCommonSymptoms() {
  const symptomCount: Record<string, number> = {};
  symptomDatabase.forEach(disease => {
    disease.symptoms.forEach(symptom => {
      symptomCount[symptom] = (symptomCount[symptom] || 0) + 1;
    });
  });
  
  return Object.entries(symptomCount)
    .sort(([,a], [,b]) => (b as number) - (a as number))
    .slice(0, 10)
    .map(([symptom, count]) => ({
      symptom: symptom.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      count: count as number
    }));
}
