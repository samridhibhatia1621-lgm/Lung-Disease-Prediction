"""
Dataset Download Script for Lung Disease Detection System
Downloads and organizes datasets from Kaggle and other sources
"""

import os
import zipfile
import shutil
from pathlib import Path
import kaggle
from tqdm import tqdm
import pandas as pd
import sys
sys.path.append(str(Path(__file__).parent.parent))

from config import DATASET_CONFIG, DATASET_URLS, DISEASE_CLASSES

class DatasetDownloader:
    def __init__(self):
        self.raw_data_path = DATASET_CONFIG["raw_data_path"]
        self.raw_data_path.mkdir(parents=True, exist_ok=True)
        
        # Check Kaggle API credentials
        self._check_kaggle_credentials()
    
    def _check_kaggle_credentials(self):
        """Check if Kaggle API credentials are configured"""
        try:
            kaggle.api.authenticate()
            print("✅ Kaggle API credentials found")
        except Exception as e:
            print("❌ Kaggle API credentials not found!")
            print("Please follow these steps:")
            print("1. Go to https://www.kaggle.com/account")
            print("2. Click 'Create New API Token'")
            print("3. Place kaggle.json in ~/.kaggle/ (Linux/Mac) or C:\\Users\\<username>\\.kaggle\\ (Windows)")
            print("4. Run: chmod 600 ~/.kaggle/kaggle.json (Linux/Mac only)")
            raise e
    
    def download_pneumonia_dataset(self):
        """Download Chest X-Ray Images (Pneumonia) dataset"""
        print("\n📥 Downloading Pneumonia dataset...")
        
        dataset_path = self.raw_data_path / "pneumonia"
        dataset_path.mkdir(exist_ok=True)
        
        try:
            kaggle.api.dataset_download_files(
                DATASET_URLS["pneumonia"],
                path=str(dataset_path),
                unzip=True
            )
            print("✅ Pneumonia dataset downloaded successfully")
            return True
        except Exception as e:
            print(f"❌ Error downloading pneumonia dataset: {e}")
            return False
    
    def download_covid19_dataset(self):
        """Download COVID-19 Radiography Database"""
        print("\n📥 Downloading COVID-19 dataset...")
        
        dataset_path = self.raw_data_path / "covid19"
        dataset_path.mkdir(exist_ok=True)
        
        try:
            kaggle.api.dataset_download_files(
                DATASET_URLS["covid19"],
                path=str(dataset_path),
                unzip=True
            )
            print("✅ COVID-19 dataset downloaded successfully")
            return True
        except Exception as e:
            print(f"❌ Error downloading COVID-19 dataset: {e}")
            return False
    
    def download_nih_dataset(self):
        """Download NIH Chest X-rays dataset (subset)"""
        print("\n📥 Downloading NIH Chest X-rays dataset...")
        print("⚠️  Note: This is a large dataset. Downloading sample subset...")
        
        dataset_path = self.raw_data_path / "nih_chest"
        dataset_path.mkdir(exist_ok=True)
        
        try:
            # Download metadata first
            kaggle.api.dataset_download_files(
                "nih-chest-xrays/sample",  # Using sample dataset
                path=str(dataset_path),
                unzip=True
            )
            print("✅ NIH Chest X-rays sample downloaded successfully")
            return True
        except Exception as e:
            print(f"❌ Error downloading NIH dataset: {e}")
            print("💡 Tip: You can manually download from: https://www.kaggle.com/nih-chest-xrays/data")
            return False
    
    def download_tuberculosis_dataset(self):
        """Download Tuberculosis dataset"""
        print("\n📥 Downloading Tuberculosis dataset...")
        
        dataset_path = self.raw_data_path / "tuberculosis"
        dataset_path.mkdir(exist_ok=True)
        
        try:
            kaggle.api.dataset_download_files(
                DATASET_URLS["tuberculosis"],
                path=str(dataset_path),
                unzip=True
            )
            print("✅ Tuberculosis dataset downloaded successfully")
            return True
        except Exception as e:
            print(f"❌ Error downloading tuberculosis dataset: {e}")
            return False
    
    def organize_datasets(self):
        """Organize downloaded datasets into standardized structure"""
        print("\n📁 Organizing datasets...")
        
        organized_path = self.raw_data_path / "organized"
        organized_path.mkdir(exist_ok=True)
        
        # Create class directories
        for disease_class in DISEASE_CLASSES:
            class_dir = organized_path / disease_class
            class_dir.mkdir(exist_ok=True)
        
        # Organize pneumonia dataset
        self._organize_pneumonia_data(organized_path)
        
        # Organize COVID-19 dataset
        self._organize_covid19_data(organized_path)
        
        # Organize tuberculosis dataset
        self._organize_tuberculosis_data(organized_path)
        
        print("✅ Dataset organization completed")
    
    def _organize_pneumonia_data(self, organized_path):
        """Organize pneumonia dataset"""
        pneumonia_path = self.raw_data_path / "pneumonia"
        
        if not pneumonia_path.exists():
            return
        
        print("  📂 Organizing pneumonia data...")
        
        # Find chest_xray directory
        chest_xray_dirs = list(pneumonia_path.rglob("chest_xray"))
        if not chest_xray_dirs:
            print("    ⚠️  Chest X-ray directory not found in pneumonia dataset")
            return
        
        chest_xray_path = chest_xray_dirs[0]
        
        # Copy normal images
        normal_dirs = list(chest_xray_path.rglob("NORMAL"))
        for normal_dir in normal_dirs:
            if normal_dir.is_dir():
                for img_file in normal_dir.glob("*.jpeg"):
                    shutil.copy2(img_file, organized_path / "Normal")
        
        # Copy pneumonia images
        pneumonia_dirs = list(chest_xray_path.rglob("PNEUMONIA"))
        for pneumonia_dir in pneumonia_dirs:
            if pneumonia_dir.is_dir():
                for img_file in pneumonia_dir.glob("*.jpeg"):
                    shutil.copy2(img_file, organized_path / "Pneumonia")
    
    def _organize_covid19_data(self, organized_path):
        """Organize COVID-19 dataset"""
        covid_path = self.raw_data_path / "covid19"
        
        if not covid_path.exists():
            return
        
        print("  📂 Organizing COVID-19 data...")
        
        # Look for COVID-19 Radiography Dataset directory
        covid_dirs = list(covid_path.rglob("*COVID*"))
        if not covid_dirs:
            covid_dirs = list(covid_path.glob("*"))
        
        for covid_dir in covid_dirs:
            if covid_dir.is_dir():
                # Copy COVID images
                covid_images = list(covid_dir.glob("COVID*.png")) + list(covid_dir.glob("COVID*.jpg"))
                for img_file in covid_images[:2000]:  # Limit to 2000 images
                    shutil.copy2(img_file, organized_path / "COVID-19")
                
                # Copy normal images
                normal_images = list(covid_dir.glob("Normal*.png")) + list(covid_dir.glob("Normal*.jpg"))
                for img_file in normal_images[:1000]:  # Limit to 1000 images
                    shutil.copy2(img_file, organized_path / "Normal")
    
    def _organize_tuberculosis_data(self, organized_path):
        """Organize tuberculosis dataset"""
        tb_path = self.raw_data_path / "tuberculosis"
        
        if not tb_path.exists():
            return
        
        print("  📂 Organizing tuberculosis data...")
        
        # Look for tuberculosis images
        tb_dirs = list(tb_path.glob("*"))
        for tb_dir in tb_dirs:
            if tb_dir.is_dir():
                # Copy TB images (look for various naming patterns)
                tb_images = (list(tb_dir.glob("*tb*.png")) + 
                           list(tb_dir.glob("*TB*.png")) +
                           list(tb_dir.glob("*tuberculosis*.png")) +
                           list(tb_dir.glob("*tb*.jpg")) + 
                           list(tb_dir.glob("*TB*.jpg")))
                
                for img_file in tb_images[:1500]:  # Limit to 1500 images
                    shutil.copy2(img_file, organized_path / "Tuberculosis")
    
    def create_dataset_summary(self):
        """Create a summary of downloaded datasets"""
        print("\n📊 Creating dataset summary...")
        
        organized_path = self.raw_data_path / "organized"
        summary_data = []
        
        for disease_class in DISEASE_CLASSES:
            class_dir = organized_path / disease_class
            if class_dir.exists():
                image_count = len(list(class_dir.glob("*.*")))
                summary_data.append({
                    "Disease_Class": disease_class,
                    "Image_Count": image_count,
                    "Path": str(class_dir)
                })
        
        # Create summary DataFrame
        summary_df = pd.DataFrame(summary_data)
        summary_file = self.raw_data_path / "dataset_summary.csv"
        summary_df.to_csv(summary_file, index=False)
        
        print("📋 Dataset Summary:")
        print(summary_df.to_string(index=False))
        print(f"\n💾 Summary saved to: {summary_file}")
        
        total_images = summary_df["Image_Count"].sum()
        print(f"\n📈 Total images downloaded: {total_images:,}")
    
    def download_all(self):
        """Download all datasets"""
        print("🚀 Starting dataset download process...")
        print("This may take a while depending on your internet connection.")
        
        success_count = 0
        
        # Download individual datasets
        if self.download_pneumonia_dataset():
            success_count += 1
        
        if self.download_covid19_dataset():
            success_count += 1
        
        if self.download_tuberculosis_dataset():
            success_count += 1
        
        # Note: NIH dataset is very large, so we skip it by default
        # Uncomment the next lines if you want to download it
        # if self.download_nih_dataset():
        #     success_count += 1
        
        print(f"\n✅ Successfully downloaded {success_count} datasets")
        
        # Organize datasets
        self.organize_datasets()
        
        # Create summary
        self.create_dataset_summary()
        
        print("\n🎉 Dataset download and organization completed!")
        print("Next steps:")
        print("1. Run: python data/preprocess.py")
        print("2. Run: python training/train_gan.py")
        print("3. Run: python training/train_classifier.py")

def main():
    """Main function to run dataset download"""
    try:
        downloader = DatasetDownloader()
        downloader.download_all()
    except KeyboardInterrupt:
        print("\n⏹️  Download interrupted by user")
    except Exception as e:
        print(f"\n❌ Error during download: {e}")
        print("Please check your internet connection and Kaggle API credentials")

if __name__ == "__main__":
    main()
