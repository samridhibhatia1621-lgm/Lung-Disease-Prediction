"""
Data Preprocessing Pipeline for Lung Disease Detection System
Handles image preprocessing, normalization, and data preparation
"""

import os
import cv2
import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tqdm import tqdm
import json
import sys
sys.path.append(str(Path(__file__).parent.parent))

from config import (
    DATASET_CONFIG, PREPROCESSING_CONFIG, DISEASE_CLASSES, 
    VALIDATION_CONFIG, AUGMENTATION_CONFIG
)

class DataPreprocessor:
    def __init__(self):
        self.raw_data_path = DATASET_CONFIG["raw_data_path"]
        self.processed_data_path = DATASET_CONFIG["processed_data_path"]
        self.processed_data_path.mkdir(parents=True, exist_ok=True)
        
        self.image_size = DATASET_CONFIG["image_size"]
        self.label_encoder = LabelEncoder()
        
    def load_and_preprocess_images(self):
        """Load and preprocess all images from organized dataset"""
        print("🔄 Loading and preprocessing images...")
        
        organized_path = self.raw_data_path / "organized"
        if not organized_path.exists():
            raise FileNotFoundError("Organized dataset not found. Run download_datasets.py first.")
        
        images = []
        labels = []
        file_paths = []
        
        for disease_class in DISEASE_CLASSES:
            class_dir = organized_path / disease_class
            if not class_dir.exists():
                print(f"⚠️  Warning: {disease_class} directory not found")
                continue
            
            print(f"  📂 Processing {disease_class}...")
            image_files = list(class_dir.glob("*.*"))
            
            for img_path in tqdm(image_files, desc=f"Loading {disease_class}"):
                try:
                    # Load and preprocess image
                    processed_img = self._preprocess_single_image(str(img_path))
                    if processed_img is not None:
                        images.append(processed_img)
                        labels.append(disease_class)
                        file_paths.append(str(img_path))
                except Exception as e:
                    print(f"    ❌ Error processing {img_path}: {e}")
                    continue
        
        print(f"✅ Loaded {len(images)} images successfully")
        
        # Convert to numpy arrays
        X = np.array(images)
        y = np.array(labels)
        
        # Encode labels
        y_encoded = self.label_encoder.fit_transform(y)
        
        return X, y_encoded, y, file_paths
    
    def _preprocess_single_image(self, img_path):
        """Preprocess a single image"""
        try:
            # Read image
            img = cv2.imread(img_path)
            if img is None:
                return None
            
            # Convert BGR to RGB
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            
            # Resize image
            img = cv2.resize(img, self.image_size, interpolation=cv2.INTER_LANCZOS4)
            
            # Apply CLAHE if enabled
            if PREPROCESSING_CONFIG["clahe_enabled"]:
                img = self._apply_clahe(img)
            
            # Apply Gaussian blur if enabled
            if PREPROCESSING_CONFIG["gaussian_blur"]:
                img = cv2.GaussianBlur(
                    img, 
                    PREPROCESSING_CONFIG["blur_kernel_size"], 
                    0
                )
            
            # Normalize pixel values
            if PREPROCESSING_CONFIG["normalize"]:
                img = img.astype(np.float32) / 255.0
            
            return img
            
        except Exception as e:
            print(f"Error preprocessing image {img_path}: {e}")
            return None
    
    def _apply_clahe(self, img):
        """Apply Contrast Limited Adaptive Histogram Equalization"""
        # Convert to LAB color space
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        
        # Apply CLAHE to L channel
        clahe = cv2.createCLAHE(
            clipLimit=PREPROCESSING_CONFIG["clahe_clip_limit"],
            tileGridSize=PREPROCESSING_CONFIG["clahe_tile_grid_size"]
        )
        lab[:, :, 0] = clahe.apply(lab[:, :, 0])
        
        # Convert back to RGB
        img = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
        return img
    
    def split_dataset(self, X, y, y_labels, file_paths):
        """Split dataset into train, validation, and test sets"""
        print("🔄 Splitting dataset...")
        
        # First split: separate test set
        X_temp, X_test, y_temp, y_test, y_labels_temp, y_labels_test, paths_temp, paths_test = train_test_split(
            X, y, y_labels, file_paths,
            test_size=DATASET_CONFIG["test_split"],
            stratify=y,
            random_state=VALIDATION_CONFIG["random_state"],
            shuffle=VALIDATION_CONFIG["shuffle"]
        )
        
        # Second split: separate train and validation
        val_size = DATASET_CONFIG["validation_split"] / (1 - DATASET_CONFIG["test_split"])
        X_train, X_val, y_train, y_val, y_labels_train, y_labels_val, paths_train, paths_val = train_test_split(
            X_temp, y_temp, y_labels_temp, paths_temp,
            test_size=val_size,
            stratify=y_temp,
            random_state=VALIDATION_CONFIG["random_state"],
            shuffle=VALIDATION_CONFIG["shuffle"]
        )
        
        print(f"  📊 Train set: {len(X_train)} images")
        print(f"  📊 Validation set: {len(X_val)} images")
        print(f"  📊 Test set: {len(X_test)} images")
        
        return {
            'train': (X_train, y_train, y_labels_train, paths_train),
            'val': (X_val, y_val, y_labels_val, paths_val),
            'test': (X_test, y_test, y_labels_test, paths_test)
        }
    
    def save_processed_data(self, data_splits):
        """Save processed data to disk"""
        print("💾 Saving processed data...")
        
        for split_name, (X, y, y_labels, paths) in data_splits.items():
            split_dir = self.processed_data_path / split_name
            split_dir.mkdir(exist_ok=True)
            
            # Save arrays
            np.save(split_dir / "X.npy", X)
            np.save(split_dir / "y.npy", y)
            np.save(split_dir / "y_labels.npy", y_labels)
            
            # Save file paths
            with open(split_dir / "file_paths.json", 'w') as f:
                json.dump(paths, f, indent=2)
        
        # Save label encoder
        import joblib
        joblib.dump(self.label_encoder, self.processed_data_path / "label_encoder.pkl")
        
        # Save preprocessing metadata
        metadata = {
            "image_size": self.image_size,
            "disease_classes": DISEASE_CLASSES,
            "preprocessing_config": PREPROCESSING_CONFIG,
            "total_samples": sum(len(split[0]) for split in data_splits.values())
        }
        
        with open(self.processed_data_path / "metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print("✅ Processed data saved successfully")
    
    def create_data_visualization(self, data_splits):
        """Create visualizations of the processed dataset"""
        print("📊 Creating data visualizations...")
        
        # Class distribution
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        for idx, (split_name, (X, y, y_labels, _)) in enumerate(data_splits.items()):
            if idx < 3:  # Only plot first 3 splits
                row, col = idx // 2, idx % 2
                
                # Count classes
                unique, counts = np.unique(y_labels, return_counts=True)
                
                axes[row, col].bar(unique, counts, color='skyblue', alpha=0.7)
                axes[row, col].set_title(f'{split_name.capitalize()} Set Distribution')
                axes[row, col].set_xlabel('Disease Class')
                axes[row, col].set_ylabel('Number of Images')
                axes[row, col].tick_params(axis='x', rotation=45)
        
        # Sample images
        X_train, y_train, y_labels_train, _ = data_splits['train']
        
        # Show sample images from each class
        axes[1, 1].axis('off')
        
        plt.tight_layout()
        plt.savefig(self.processed_data_path / "data_distribution.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        # Create sample images grid
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        axes = axes.flatten()
        
        for idx, disease_class in enumerate(DISEASE_CLASSES):
            if idx < 6:  # Show first 6 classes
                # Find first image of this class
                class_indices = np.where(y_labels_train == disease_class)[0]
                if len(class_indices) > 0:
                    sample_img = X_train[class_indices[0]]
                    
                    # Denormalize if normalized
                    if PREPROCESSING_CONFIG["normalize"]:
                        sample_img = (sample_img * 255).astype(np.uint8)
                    
                    axes[idx].imshow(sample_img)
                    axes[idx].set_title(f'{disease_class}')
                    axes[idx].axis('off')
        
        plt.tight_layout()
        plt.savefig(self.processed_data_path / "sample_images.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        print("✅ Visualizations saved")
    
    def generate_statistics(self, data_splits):
        """Generate dataset statistics"""
        print("📈 Generating dataset statistics...")
        
        stats = {
            "dataset_summary": {},
            "class_distribution": {},
            "image_statistics": {}
        }
        
        total_images = 0
        all_y_labels = []
        
        for split_name, (X, y, y_labels, _) in data_splits.items():
            stats["dataset_summary"][split_name] = {
                "total_images": len(X),
                "image_shape": X.shape[1:],
                "data_type": str(X.dtype)
            }
            total_images += len(X)
            all_y_labels.extend(y_labels)
        
        stats["dataset_summary"]["total"] = total_images
        
        # Class distribution
        unique_classes, class_counts = np.unique(all_y_labels, return_counts=True)
        for class_name, count in zip(unique_classes, class_counts):
            stats["class_distribution"][class_name] = {
                "count": int(count),
                "percentage": float(count / total_images * 100)
            }
        
        # Image statistics
        X_sample = data_splits['train'][0][:1000]  # Sample for statistics
        stats["image_statistics"] = {
            "mean_pixel_value": float(np.mean(X_sample)),
            "std_pixel_value": float(np.std(X_sample)),
            "min_pixel_value": float(np.min(X_sample)),
            "max_pixel_value": float(np.max(X_sample))
        }
        
        # Save statistics
        with open(self.processed_data_path / "statistics.json", 'w') as f:
            json.dump(stats, f, indent=2)
        
        print("📋 Dataset Statistics:")
        print(f"  Total Images: {total_images:,}")
        print(f"  Classes: {len(unique_classes)}")
        print(f"  Image Size: {X_sample.shape[1:]}")
        
        return stats
    
    def process_all(self):
        """Run complete preprocessing pipeline"""
        print("🚀 Starting data preprocessing pipeline...")
        
        try:
            # Load and preprocess images
            X, y, y_labels, file_paths = self.load_and_preprocess_images()
            
            # Split dataset
            data_splits = self.split_dataset(X, y, y_labels, file_paths)
            
            # Save processed data
            self.save_processed_data(data_splits)
            
            # Create visualizations
            self.create_data_visualization(data_splits)
            
            # Generate statistics
            self.generate_statistics(data_splits)
            
            print("🎉 Data preprocessing completed successfully!")
            print("Next steps:")
            print("1. Run: python training/train_gan.py")
            print("2. Run: python data/augmentation.py")
            print("3. Run: python training/train_classifier.py")
            
        except Exception as e:
            print(f"❌ Error during preprocessing: {e}")
            raise

def main():
    """Main function to run preprocessing"""
    try:
        preprocessor = DataPreprocessor()
        preprocessor.process_all()
    except KeyboardInterrupt:
        print("\n⏹️  Preprocessing interrupted by user")
    except Exception as e:
        print(f"\n❌ Error during preprocessing: {e}")

if __name__ == "__main__":
    main()
