"""
Generative Adversarial Network (GAN) for Data Augmentation
Generates synthetic chest X-ray images to balance the dataset
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import json
import sys
sys.path.append(str(Path(__file__).parent.parent))

from config import GAN_CONFIG, DATASET_CONFIG, DISEASE_CLASSES

class ChestXrayGAN:
    def __init__(self):
        self.latent_dim = GAN_CONFIG["latent_dim"]
        self.img_shape = (*DATASET_CONFIG["image_size"], 3)
        self.generator = None
        self.discriminator = None
        self.gan = None
        
    def build_generator(self):
        """Build the generator network"""
        model = keras.Sequential([
            # Input layer
            layers.Dense(7 * 7 * 256, input_dim=self.latent_dim),
            layers.Reshape((7, 7, 256)),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            
            # Upsampling layers
            layers.Conv2DTranspose(128, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            
            layers.Conv2DTranspose(64, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            
            layers.Conv2DTranspose(32, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            
            layers.Conv2DTranspose(16, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            
            # Output layer
            layers.Conv2DTranspose(3, (5, 5), strides=(2, 2), padding='same'),
            layers.Activation('tanh')
        ], name="generator")
        
        return model
    
    def build_discriminator(self):
        """Build the discriminator network"""
        model = keras.Sequential([
            # Input layer
            layers.Conv2D(32, (5, 5), strides=(2, 2), padding='same', 
                         input_shape=self.img_shape),
            layers.LeakyReLU(alpha=0.2),
            layers.Dropout(0.3),
            
            # Downsampling layers
            layers.Conv2D(64, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            layers.Dropout(0.3),
            
            layers.Conv2D(128, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            layers.Dropout(0.3),
            
            layers.Conv2D(256, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            layers.Dropout(0.3),
            
            layers.Conv2D(512, (5, 5), strides=(2, 2), padding='same'),
            layers.BatchNormalization(),
            layers.LeakyReLU(alpha=0.2),
            layers.Dropout(0.3),
            
            # Output layer
            layers.Flatten(),
            layers.Dense(1, activation='sigmoid')
        ], name="discriminator")
        
        return model
    
    def build_gan(self):
        """Build the complete GAN model"""
        # Build generator and discriminator
        self.generator = self.build_generator()
        self.discriminator = self.build_discriminator()
        
        # Compile discriminator
        self.discriminator.compile(
            optimizer=keras.optimizers.Adam(
                learning_rate=GAN_CONFIG["learning_rate"],
                beta_1=GAN_CONFIG["beta1"]
            ),
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        # Build and compile GAN
        self.discriminator.trainable = False
        
        gan_input = keras.Input(shape=(self.latent_dim,))
        generated_img = self.generator(gan_input)
        gan_output = self.discriminator(generated_img)
        
        self.gan = keras.Model(gan_input, gan_output, name="gan")
        self.gan.compile(
            optimizer=keras.optimizers.Adam(
                learning_rate=GAN_CONFIG["learning_rate"],
                beta_1=GAN_CONFIG["beta1"]
            ),
            loss='binary_crossentropy'
        )
        
        print("✅ GAN model built successfully")
        print(f"Generator parameters: {self.generator.count_params():,}")
        print(f"Discriminator parameters: {self.discriminator.count_params():,}")
    
    def train(self, X_train, epochs=None, batch_size=None, save_interval=None):
        """Train the GAN model"""
        if epochs is None:
            epochs = GAN_CONFIG["epochs"]
        if batch_size is None:
            batch_size = GAN_CONFIG["batch_size"]
        if save_interval is None:
            save_interval = GAN_CONFIG["save_interval"]
        
        print(f"🚀 Starting GAN training for {epochs} epochs...")
        
        # Normalize data to [-1, 1] for tanh activation
        X_train = (X_train - 0.5) * 2.0
        
        # Training history
        history = {
            'discriminator_loss': [],
            'discriminator_accuracy': [],
            'generator_loss': []
        }
        
        for epoch in range(epochs):
            # Train discriminator
            d_loss_real, d_acc_real = self._train_discriminator_real(X_train, batch_size)
            d_loss_fake, d_acc_fake = self._train_discriminator_fake(batch_size)
            
            d_loss = 0.5 * (d_loss_real + d_loss_fake)
            d_acc = 0.5 * (d_acc_real + d_acc_fake)
            
            # Train generator
            g_loss = self._train_generator(batch_size)
            
            # Record history
            history['discriminator_loss'].append(float(d_loss))
            history['discriminator_accuracy'].append(float(d_acc))
            history['generator_loss'].append(float(g_loss))
            
            # Print progress
            if epoch % 10 == 0:
                print(f"Epoch {epoch}/{epochs} - D_loss: {d_loss:.4f}, D_acc: {d_acc:.4f}, G_loss: {g_loss:.4f}")
            
            # Save sample images
            if epoch % GAN_CONFIG["sample_interval"] == 0:
                self._save_sample_images(epoch)
            
            # Save model
            if epoch % save_interval == 0 and epoch > 0:
                self._save_models(epoch)
        
        print("✅ GAN training completed!")
        return history
    
    def _train_discriminator_real(self, X_train, batch_size):
        """Train discriminator on real images"""
        # Select random batch of real images
        idx = np.random.randint(0, X_train.shape[0], batch_size)
        real_imgs = X_train[idx]
        
        # Labels for real images (with label smoothing)
        real_labels = np.ones((batch_size, 1)) * 0.9
        
        # Train discriminator
        d_loss_real = self.discriminator.train_on_batch(real_imgs, real_labels)
        return d_loss_real
    
    def _train_discriminator_fake(self, batch_size):
        """Train discriminator on fake images"""
        # Generate fake images
        noise = np.random.normal(0, 1, (batch_size, self.latent_dim))
        fake_imgs = self.generator.predict(noise, verbose=0)
        
        # Labels for fake images
        fake_labels = np.zeros((batch_size, 1))
        
        # Train discriminator
        d_loss_fake = self.discriminator.train_on_batch(fake_imgs, fake_labels)
        return d_loss_fake
    
    def _train_generator(self, batch_size):
        """Train generator"""
        # Generate noise
        noise = np.random.normal(0, 1, (batch_size, self.latent_dim))
        
        # Labels for generator (wants discriminator to think images are real)
        valid_labels = np.ones((batch_size, 1))
        
        # Train generator
        g_loss = self.gan.train_on_batch(noise, valid_labels)
        return g_loss
    
    def _save_sample_images(self, epoch, num_samples=16):
        """Save sample generated images"""
        noise = np.random.normal(0, 1, (num_samples, self.latent_dim))
        generated_imgs = self.generator.predict(noise, verbose=0)
        
        # Rescale images to [0, 1]
        generated_imgs = (generated_imgs + 1) / 2.0
        
        # Create grid
        fig, axes = plt.subplots(4, 4, figsize=(10, 10))
        axes = axes.flatten()
        
        for i in range(num_samples):
            axes[i].imshow(generated_imgs[i])
            axes[i].axis('off')
        
        plt.tight_layout()
        
        # Save image
        samples_dir = Path("ML_Implementation/models/samples")
        samples_dir.mkdir(exist_ok=True)
        plt.savefig(samples_dir / f"generated_epoch_{epoch}.png", dpi=150, bbox_inches='tight')
        plt.close()
    
    def _save_models(self, epoch):
        """Save generator and discriminator models"""
        models_dir = Path("ML_Implementation/models")
        
        self.generator.save(models_dir / f"generator_epoch_{epoch}.h5")
        self.discriminator.save(models_dir / f"discriminator_epoch_{epoch}.h5")
        
        print(f"💾 Models saved at epoch {epoch}")
    
    def generate_images(self, num_images, class_name=None):
        """Generate synthetic images"""
        if self.generator is None:
            raise ValueError("Generator not built. Call build_gan() first.")
        
        noise = np.random.normal(0, 1, (num_images, self.latent_dim))
        generated_imgs = self.generator.predict(noise, verbose=0)
        
        # Rescale to [0, 1]
        generated_imgs = (generated_imgs + 1) / 2.0
        
        return generated_imgs
    
    def save_final_models(self):
        """Save final trained models"""
        models_dir = Path("ML_Implementation/models")
        
        self.generator.save(models_dir / "gan_generator.h5")
        self.discriminator.save(models_dir / "gan_discriminator.h5")
        
        print("💾 Final GAN models saved")
    
    def load_models(self, generator_path=None, discriminator_path=None):
        """Load pre-trained models"""
        models_dir = Path("ML_Implementation/models")
        
        if generator_path is None:
            generator_path = models_dir / "gan_generator.h5"
        if discriminator_path is None:
            discriminator_path = models_dir / "gan_discriminator.h5"
        
        if generator_path.exists():
            self.generator = keras.models.load_model(generator_path)
            print("✅ Generator loaded")
        
        if discriminator_path.exists():
            self.discriminator = keras.models.load_model(discriminator_path)
            print("✅ Discriminator loaded")

class ConditionalGAN(ChestXrayGAN):
    """Conditional GAN for class-specific image generation"""
    
    def __init__(self):
        super().__init__()
        self.num_classes = len(DISEASE_CLASSES)
    
    def build_conditional_generator(self):
        """Build conditional generator with class labels"""
        # Noise input
        noise_input = keras.Input(shape=(self.latent_dim,))
        
        # Class label input
        label_input = keras.Input(shape=(1,))
        label_embedding = layers.Embedding(self.num_classes, 50)(label_input)
        label_embedding = layers.Flatten()(label_embedding)
        
        # Combine noise and label
        combined_input = layers.Concatenate()([noise_input, label_embedding])
        
        # Generator layers
        x = layers.Dense(7 * 7 * 256)(combined_input)
        x = layers.Reshape((7, 7, 256))(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        
        # Upsampling layers (same as before)
        x = layers.Conv2DTranspose(128, (5, 5), strides=(2, 2), padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        
        x = layers.Conv2DTranspose(64, (5, 5), strides=(2, 2), padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        
        x = layers.Conv2DTranspose(32, (5, 5), strides=(2, 2), padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        
        x = layers.Conv2DTranspose(16, (5, 5), strides=(2, 2), padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        
        output = layers.Conv2DTranspose(3, (5, 5), strides=(2, 2), padding='same', activation='tanh')(x)
        
        model = keras.Model([noise_input, label_input], output, name="conditional_generator")
        return model
    
    def build_conditional_discriminator(self):
        """Build conditional discriminator with class labels"""
        # Image input
        img_input = keras.Input(shape=self.img_shape)
        
        # Class label input
        label_input = keras.Input(shape=(1,))
        label_embedding = layers.Embedding(self.num_classes, 50)(label_input)
        label_embedding = layers.Flatten()(label_embedding)
        label_embedding = layers.Dense(np.prod(self.img_shape))(label_embedding)
        label_embedding = layers.Reshape(self.img_shape)(label_embedding)
        
        # Combine image and label
        combined_input = layers.Concatenate()([img_input, label_embedding])
        
        # Discriminator layers
        x = layers.Conv2D(32, (5, 5), strides=(2, 2), padding='same')(combined_input)
        x = layers.LeakyReLU(alpha=0.2)(x)
        x = layers.Dropout(0.3)(x)
        
        x = layers.Conv2D(64, (5, 5), strides=(2, 2), padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        x = layers.Dropout(0.3)(x)
        
        x = layers.Conv2D(128, (5, 5), strides=(2, 2), padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        x = layers.Dropout(0.3)(x)
        
        x = layers.Conv2D(256, (5, 5), strides=(2, 2), padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU(alpha=0.2)(x)
        x = layers.Dropout(0.3)(x)
        
        x = layers.Flatten()(x)
        output = layers.Dense(1, activation='sigmoid')(x)
        
        model = keras.Model([img_input, label_input], output, name="conditional_discriminator")
        return model
