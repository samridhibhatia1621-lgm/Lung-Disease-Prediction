"""
Deep Learning Classifier for Lung Disease Detection
Uses transfer learning with EfficientNet for multi-class classification
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, applications
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
from pathlib import Path
import json
import sys
sys.path.append(str(Path(__file__).parent.parent))

from config import CLASSIFIER_CONFIG, DATASET_CONFIG, DISEASE_CLASSES, TRAINING_CONFIG

class LungDiseaseClassifier:
    def __init__(self):
        self.model = None
        self.history = None
        self.img_shape = (*DATASET_CONFIG["image_size"], 3)
        self.num_classes = len(DISEASE_CLASSES)
        
    def build_model(self, model_name=None):
        """Build the classification model using transfer learning"""
        if model_name is None:
            model_name = CLASSIFIER_CONFIG["model_name"]
        
        print(f"🏗️  Building {model_name} model...")
        
        # Load pre-trained base model
        if model_name == "efficientnet_b0":
            base_model = applications.EfficientNetB0(
                weights='imagenet',
                include_top=False,
                input_shape=self.img_shape
            )
        elif model_name == "resnet50":
            base_model = applications.ResNet50(
                weights='imagenet',
                include_top=False,
                input_shape=self.img_shape
            )
        elif model_name == "densenet121":
            base_model = applications.DenseNet121(
                weights='imagenet',
                include_top=False,
                input_shape=self.img_shape
            )
        else:
            raise ValueError(f"Unsupported model: {model_name}")
        
        # Freeze base model initially
        base_model.trainable = False
        
        # Add custom classification head
        inputs = keras.Input(shape=self.img_shape)
        
        # Preprocessing
        x = keras.applications.imagenet_utils.preprocess_input(inputs)
        
        # Base model
        x = base_model(x, training=False)
        
        # Global average pooling
        x = layers.GlobalAveragePooling2D()(x)
        
        # Dropout for regularization
        x = layers.Dropout(CLASSIFIER_CONFIG["dropout_rate"])(x)
        
        # Dense layers
        x = layers.Dense(512, activation='relu',
                        kernel_regularizer=keras.regularizers.l2(CLASSIFIER_CONFIG["l2_regularization"]))(x)
        x = layers.BatchNormalization()(x)
        x = layers.Dropout(CLASSIFIER_CONFIG["dropout_rate"])(x)
        
        x = layers.Dense(256, activation='relu',
                        kernel_regularizer=keras.regularizers.l2(CLASSIFIER_CONFIG["l2_regularization"]))(x)
        x = layers.BatchNormalization()(x)
        x = layers.Dropout(CLASSIFIER_CONFIG["dropout_rate"])(x)
        
        # Output layer
        outputs = layers.Dense(self.num_classes, activation='softmax', name='predictions')(x)
        
        self.model = keras.Model(inputs, outputs, name=f"lung_classifier_{model_name}")
        
        print(f"✅ Model built successfully")
        print(f"Total parameters: {self.model.count_params():,}")
        print(f"Trainable parameters: {sum([tf.keras.backend.count_params(w) for w in self.model.trainable_weights]):,}")
        
        return self.model
    
    def compile_model(self):
        """Compile the model with optimizer, loss, and metrics"""
        optimizer = keras.optimizers.Adam(
            learning_rate=CLASSIFIER_CONFIG["learning_rate"]
        )
        
        self.model.compile(
            optimizer=optimizer,
            loss=CLASSIFIER_CONFIG["loss_function"],
            metrics=CLASSIFIER_CONFIG["metrics"]
        )
        
        print("✅ Model compiled successfully")
    
    def create_callbacks(self):
        """Create training callbacks"""
        callbacks = []
        
        # Early stopping
        early_stopping = keras.callbacks.EarlyStopping(
            monitor=TRAINING_CONFIG["monitor_metric"],
            patience=CLASSIFIER_CONFIG["early_stopping_patience"],
            restore_best_weights=True,
            verbose=1
        )
        callbacks.append(early_stopping)
        
        # Reduce learning rate on plateau
        reduce_lr = keras.callbacks.ReduceLROnPlateau(
            monitor=TRAINING_CONFIG["monitor_metric"],
            factor=0.2,
            patience=CLASSIFIER_CONFIG["reduce_lr_patience"],
            min_lr=1e-7,
            verbose=1
        )
        callbacks.append(reduce_lr)
        
        # Model checkpoint
        checkpoint = keras.callbacks.ModelCheckpoint(
            filepath="ML_Implementation/models/best_lung_classifier.h5",
            monitor=TRAINING_CONFIG["monitor_metric"],
            save_best_only=TRAINING_CONFIG["save_best_only"],
            mode=TRAINING_CONFIG["mode"],
            verbose=1
        )
        callbacks.append(checkpoint)
        
        # TensorBoard logging
        if TRAINING_CONFIG["use_tensorboard"]:
            tensorboard = keras.callbacks.TensorBoard(
                log_dir="ML_Implementation/logs/tensorboard",
                histogram_freq=1,
                write_graph=True,
                write_images=True
            )
            callbacks.append(tensorboard)
        
        return callbacks
    
    def create_data_generators(self, X_train, y_train, X_val, y_val):
        """Create data generators with augmentation"""
        from tensorflow.keras.preprocessing.image import ImageDataGenerator
        from config import AUGMENTATION_CONFIG
        
        # Training data generator with augmentation
        train_datagen = ImageDataGenerator(
            rotation_range=AUGMENTATION_CONFIG["rotation_range"],
            width_shift_range=AUGMENTATION_CONFIG["width_shift_range"],
            height_shift_range=AUGMENTATION_CONFIG["height_shift_range"],
            zoom_range=AUGMENTATION_CONFIG["zoom_range"],
            horizontal_flip=AUGMENTATION_CONFIG["horizontal_flip"],
            brightness_range=AUGMENTATION_CONFIG["brightness_range"],
            fill_mode=AUGMENTATION_CONFIG["fill_mode"],
            rescale=1./255 if not np.max(X_train) <= 1 else None
        )
        
        # Validation data generator (no augmentation)
        val_datagen = ImageDataGenerator(
            rescale=1./255 if not np.max(X_val) <= 1 else None
        )
        
        # Convert labels to categorical
        y_train_cat = keras.utils.to_categorical(y_train, self.num_classes)
        y_val_cat = keras.utils.to_categorical(y_val, self.num_classes)
        
        # Create generators
        train_generator = train_datagen.flow(
            X_train, y_train_cat,
            batch_size=CLASSIFIER_CONFIG["batch_size"],
            shuffle=True
        )
        
        val_generator = val_datagen.flow(
            X_val, y_val_cat,
            batch_size=CLASSIFIER_CONFIG["batch_size"],
            shuffle=False
        )
        
        return train_generator, val_generator
    
    def train(self, X_train, y_train, X_val, y_val, epochs=None):
        """Train the model"""
        if epochs is None:
            epochs = CLASSIFIER_CONFIG["epochs"]
        
        print(f"🚀 Starting training for {epochs} epochs...")
        
        # Create data generators
        train_gen, val_gen = self.create_data_generators(X_train, y_train, X_val, y_val)
        
        # Create callbacks
        callbacks = self.create_callbacks()
        
        # Calculate steps
        steps_per_epoch = len(X_train) // CLASSIFIER_CONFIG["batch_size"]
        validation_steps = len(X_val) // CLASSIFIER_CONFIG["batch_size"]
        
        # Train model
        self.history = self.model.fit(
            train_gen,
            steps_per_epoch=steps_per_epoch,
            epochs=epochs,
            validation_data=val_gen,
            validation_steps=validation_steps,
            callbacks=callbacks,
            verbose=TRAINING_CONFIG["verbose"]
        )
        
        print("✅ Training completed!")
        return self.history
    
    def fine_tune(self, X_train, y_train, X_val, y_val, fine_tune_epochs=10):
        """Fine-tune the model by unfreezing some layers"""
        print("🔧 Starting fine-tuning...")
        
        # Unfreeze the top layers of the base model
        base_model = self.model.layers[2]  # Assuming base model is the 3rd layer
        base_model.trainable = True
        
        # Fine-tune from this layer onwards
        fine_tune_at = len(base_model.layers) - 20
        
        # Freeze all the layers before fine_tune_at
        for layer in base_model.layers[:fine_tune_at]:
            layer.trainable = False
        
        # Use a lower learning rate for fine-tuning
        self.model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=CLASSIFIER_CONFIG["learning_rate"] / 10),
            loss=CLASSIFIER_CONFIG["loss_function"],
            metrics=CLASSIFIER_CONFIG["metrics"]
        )
        
        print(f"Trainable parameters after fine-tuning: {sum([tf.keras.backend.count_params(w) for w in self.model.trainable_weights]):,}")
        
        # Continue training
        fine_tune_history = self.train(X_train, y_train, X_val, y_val, epochs=fine_tune_epochs)
        
        return fine_tune_history
    
    def evaluate(self, X_test, y_test):
        """Evaluate the model on test data"""
        print("📊 Evaluating model...")
        
        # Convert labels to categorical
        y_test_cat = keras.utils.to_categorical(y_test, self.num_classes)
        
        # Evaluate
        test_loss, test_acc = self.model.evaluate(X_test, y_test_cat, verbose=0)
        
        # Predictions
        y_pred = self.model.predict(X_test, verbose=0)
        y_pred_classes = np.argmax(y_pred, axis=1)
        
        # Classification report
        report = classification_report(
            y_test, y_pred_classes,
            target_names=DISEASE_CLASSES,
            output_dict=True
        )
        
        # Confusion matrix
        cm = confusion_matrix(y_test, y_pred_classes)
        
        print(f"Test Accuracy: {test_acc:.4f}")
        print(f"Test Loss: {test_loss:.4f}")
        
        return {
            'test_accuracy': test_acc,
            'test_loss': test_loss,
            'classification_report': report,
            'confusion_matrix': cm,
            'predictions': y_pred,
            'predicted_classes': y_pred_classes
        }
    
    def plot_training_history(self):
        """Plot training history"""
        if self.history is None:
            print("No training history available")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Accuracy
        axes[0, 0].plot(self.history.history['accuracy'], label='Training Accuracy')
        axes[0, 0].plot(self.history.history['val_accuracy'], label='Validation Accuracy')
        axes[0, 0].set_title('Model Accuracy')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Accuracy')
        axes[0, 0].legend()
        axes[0, 0].grid(True)
        
        # Loss
        axes[0, 1].plot(self.history.history['loss'], label='Training Loss')
        axes[0, 1].plot(self.history.history['val_loss'], label='Validation Loss')
        axes[0, 1].set_title('Model Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True)
        
        # Precision
        if 'precision' in self.history.history:
            axes[1, 0].plot(self.history.history['precision'], label='Training Precision')
            axes[1, 0].plot(self.history.history['val_precision'], label='Validation Precision')
            axes[1, 0].set_title('Model Precision')
            axes[1, 0].set_xlabel('Epoch')
            axes[1, 0].set_ylabel('Precision')
            axes[1, 0].legend()
            axes[1, 0].grid(True)
        
        # Recall
        if 'recall' in self.history.history:
            axes[1, 1].plot(self.history.history['recall'], label='Training Recall')
            axes[1, 1].plot(self.history.history['val_recall'], label='Validation Recall')
            axes[1, 1].set_title('Model Recall')
            axes[1, 1].set_xlabel('Epoch')
            axes[1, 1].set_ylabel('Recall')
            axes[1, 1].legend()
            axes[1, 1].grid(True)
        
        plt.tight_layout()
        plt.savefig("ML_Implementation/models/training_history.png", dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_confusion_matrix(self, cm):
        """Plot confusion matrix"""
        plt.figure(figsize=(10, 8))
        sns.heatmap(
            cm, 
            annot=True, 
            fmt='d', 
            cmap='Blues',
            xticklabels=DISEASE_CLASSES,
            yticklabels=DISEASE_CLASSES
        )
        plt.title('Confusion Matrix')
        plt.xlabel('Predicted Label')
        plt.ylabel('True Label')
        plt.tight_layout()
        plt.savefig("ML_Implementation/models/confusion_matrix.png", dpi=300, bbox_inches='tight')
        plt.show()
    
    def save_model(self, filepath=None):
        """Save the trained model"""
        if filepath is None:
            filepath = "ML_Implementation/models/lung_classifier.h5"
        
        self.model.save(filepath)
        print(f"💾 Model saved to {filepath}")
    
    def load_model(self, filepath=None):
        """Load a pre-trained model"""
        if filepath is None:
            filepath = "ML_Implementation/models/lung_classifier.h5"
        
        self.model = keras.models.load_model(filepath)
        print(f"✅ Model loaded from {filepath}")
    
    def predict(self, X, return_probabilities=False):
        """Make predictions on new data"""
        predictions = self.model.predict(X, verbose=0)
        
        if return_probabilities:
            return predictions
        else:
            return np.argmax(predictions, axis=1)
    
    def predict_single_image(self, image_path):
        """Predict disease for a single image"""
        import cv2
        
        # Load and preprocess image
        img = cv2.imread(str(image_path))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, DATASET_CONFIG["image_size"])
        img = img.astype(np.float32) / 255.0
        img = np.expand_dims(img, axis=0)
        
        # Predict
        prediction = self.model.predict(img, verbose=0)
        predicted_class = np.argmax(prediction, axis=1)[0]
        confidence = np.max(prediction)
        
        return {
            'predicted_class': DISEASE_CLASSES[predicted_class],
            'confidence': float(confidence),
            'probabilities': {
                disease: float(prob) 
                for disease, prob in zip(DISEASE_CLASSES, prediction[0])
            }
        }
