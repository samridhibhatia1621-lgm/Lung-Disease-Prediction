"""
Configuration file for Lung Disease Detection System
"""

import os
from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
LOGS_DIR = BASE_DIR / "logs"

# Create directories if they don't exist
for dir_path in [DATA_DIR, MODELS_DIR, LOGS_DIR]:
    dir_path.mkdir(exist_ok=True)

# Dataset Configuration
DATASET_CONFIG = {
    "raw_data_path": DATA_DIR / "raw",
    "processed_data_path": DATA_DIR / "processed",
    "augmented_data_path": DATA_DIR / "augmented",
    "image_size": (224, 224),
    "batch_size": 32,
    "validation_split": 0.2,
    "test_split": 0.1,
}

# Disease Classes
DISEASE_CLASSES = [
    "Normal",
    "Pneumonia", 
    "COVID-19",
    "Tuberculosis",
    "Lung_Cancer",
    "Pulmonary_Fibrosis"
]

NUM_CLASSES = len(DISEASE_CLASSES)

# GAN Configuration
GAN_CONFIG = {
    "latent_dim": 100,
    "epochs": 100,
    "batch_size": 64,
    "learning_rate": 0.0002,
    "beta1": 0.5,
    "sample_interval": 10,
    "save_interval": 25,
    "generator_filters": [512, 256, 128, 64],
    "discriminator_filters": [64, 128, 256, 512],
}

# Classifier Configuration  
CLASSIFIER_CONFIG = {
    "model_name": "efficientnet_b0",  # Options: efficientnet_b0, resnet50, densenet121
    "epochs": 50,
    "batch_size": 32,
    "learning_rate": 0.001,
    "optimizer": "adam",
    "loss_function": "categorical_crossentropy",
    "metrics": ["accuracy", "precision", "recall"],
    "early_stopping_patience": 10,
    "reduce_lr_patience": 5,
    "dropout_rate": 0.3,
    "l2_regularization": 0.001,
}

# Data Augmentation
AUGMENTATION_CONFIG = {
    "rotation_range": 20,
    "width_shift_range": 0.1,
    "height_shift_range": 0.1,
    "zoom_range": 0.1,
    "horizontal_flip": True,
    "brightness_range": [0.8, 1.2],
    "fill_mode": "nearest",
}

# Preprocessing Configuration
PREPROCESSING_CONFIG = {
    "normalize": True,
    "clahe_enabled": True,
    "clahe_clip_limit": 2.0,
    "clahe_tile_grid_size": (8, 8),
    "gaussian_blur": True,
    "blur_kernel_size": (3, 3),
    "resize_method": "lanczos",
}

# Training Configuration
TRAINING_CONFIG = {
    "use_mixed_precision": True,
    "use_tensorboard": True,
    "save_best_only": True,
    "monitor_metric": "val_accuracy",
    "mode": "max",
    "verbose": 1,
}

# Evaluation Metrics
EVALUATION_METRICS = [
    "accuracy",
    "precision", 
    "recall",
    "f1_score",
    "auc_roc",
    "confusion_matrix",
    "classification_report"
]

# Symptom Analysis Configuration
SYMPTOM_CONFIG = {
    "confidence_threshold": 0.6,
    "max_recommendations": 5,
    "severity_weights": {
        "mild": 1.0,
        "moderate": 1.5, 
        "severe": 2.0
    }
}

# Dataset URLs (Kaggle datasets)
DATASET_URLS = {
    "pneumonia": "paultimothymooney/chest-xray-pneumonia",
    "covid19": "tawsifurrahman/covid19-radiography-database", 
    "nih_chest": "nih-chest-xrays/data",
    "tuberculosis": "kmader/pulmonary-chest-xray-abnormalities",
}

# Model Paths
MODEL_PATHS = {
    "gan_generator": MODELS_DIR / "gan_generator.h5",
    "gan_discriminator": MODELS_DIR / "gan_discriminator.h5", 
    "classifier": MODELS_DIR / "lung_classifier.h5",
    "best_classifier": MODELS_DIR / "best_lung_classifier.h5",
    "symptom_model": MODELS_DIR / "symptom_classifier.pkl",
}

# Logging Configuration
LOGGING_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "log_file": LOGS_DIR / "training.log",
}

# API Configuration (for deployment)
API_CONFIG = {
    "host": "0.0.0.0",
    "port": 5000,
    "debug": False,
    "max_file_size": 16 * 1024 * 1024,  # 16MB
    "allowed_extensions": {"png", "jpg", "jpeg", "dcm"},
}

# Deployment Configuration
DEPLOYMENT_CONFIG = {
    "model_serving_batch_size": 1,
    "prediction_timeout": 30,  # seconds
    "max_concurrent_requests": 10,
    "enable_gpu": True,
    "gpu_memory_limit": 4096,  # MB
}

# Security Configuration
SECURITY_CONFIG = {
    "enable_cors": True,
    "cors_origins": ["http://localhost:3000", "https://yourdomain.com"],
    "rate_limit": "100 per hour",
    "max_content_length": 16 * 1024 * 1024,
}

# Monitoring Configuration
MONITORING_CONFIG = {
    "enable_wandb": False,  # Set to True if using Weights & Biases
    "wandb_project": "lung-disease-detection",
    "enable_tensorboard": True,
    "tensorboard_log_dir": LOGS_DIR / "tensorboard",
}

# Environment Variables
ENVIRONMENT = {
    "KAGGLE_USERNAME": os.getenv("KAGGLE_USERNAME"),
    "KAGGLE_KEY": os.getenv("KAGGLE_KEY"),
    "WANDB_API_KEY": os.getenv("WANDB_API_KEY"),
    "CUDA_VISIBLE_DEVICES": os.getenv("CUDA_VISIBLE_DEVICES", "0"),
}

# Validation Configuration
VALIDATION_CONFIG = {
    "cross_validation_folds": 5,
    "stratified_split": True,
    "random_state": 42,
    "shuffle": True,
}

# Export all configurations
__all__ = [
    "DATASET_CONFIG",
    "DISEASE_CLASSES", 
    "NUM_CLASSES",
    "GAN_CONFIG",
    "CLASSIFIER_CONFIG",
    "AUGMENTATION_CONFIG",
    "PREPROCESSING_CONFIG",
    "TRAINING_CONFIG",
    "EVALUATION_METRICS",
    "SYMPTOM_CONFIG",
    "DATASET_URLS",
    "MODEL_PATHS",
    "LOGGING_CONFIG",
    "API_CONFIG",
    "DEPLOYMENT_CONFIG",
    "SECURITY_CONFIG",
    "MONITORING_CONFIG",
    "ENVIRONMENT",
    "VALIDATION_CONFIG",
]
