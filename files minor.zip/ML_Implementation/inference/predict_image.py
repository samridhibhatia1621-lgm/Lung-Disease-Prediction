"""
Image prediction module for lung disease detection
Provides inference capabilities for chest X-ray images
"""

import numpy as np
import cv2
import matplotlib.pyplot as plt
from pathlib import Path
import json
import sys
sys.path.append(str(Path(__file__).parent.parent))

from tensorflow import keras
from config import DATASET_CONFIG, DISEASE_CLASSES, MODEL_PATHS
import joblib

class LungDiseasePredictor:
    def __init__(self, model_path=None):
        """Initialize the predictor with a trained model"""
        if model_path is None:
            model_path = MODEL_PATHS["best_classifier"]
        
        self.model_path = Path(model_path)
        self.model = None
        self.label_encoder = None
        self.image_size = DATASET_CONFIG["image_size"]
        
        self._load_model()
        self._load_label_encoder()
    
    def _load_model(self):
        """Load the trained model"""
        if not self.model_path.exists():
            raise FileNotFoundError(f"Model not found at {self.model_path}")
        
        print(f"📂 Loading model from {self.model_path}")
        self.model = keras.models.load_model(self.model_path)
        print("✅ Model loaded successfully")
    
    def _load_label_encoder(self):
        """Load the label encoder"""
        encoder_path = DATASET_CONFIG["processed_data_path"] / "label_encoder.pkl"
        
        if encoder_path.exists():
            self.label_encoder = joblib.load(encoder_path)
            print("✅ Label encoder loaded")
        else:
            print("⚠️  Label encoder not found, using default class names")
            self.label_encoder = None
    
    def preprocess_image(self, image_path):
        """Preprocess a single image for prediction"""
        # Read image
        img = cv2.imread(str(image_path))
        if img is None:
            raise ValueError(f"Could not load image from {image_path}")
        
        # Convert BGR to RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Resize to model input size
        img = cv2.resize(img, self.image_size, interpolation=cv2.INTER_LANCZOS4)
        
        # Normalize pixel values
        img = img.astype(np.float32) / 255.0
        
        # Add batch dimension
        img = np.expand_dims(img, axis=0)
        
        return img
    
    def predict(self, image_path, return_all_probabilities=False):
        """Predict disease from chest X-ray image"""
        print(f"🔍 Analyzing image: {image_path}")
        
        # Preprocess image
        processed_img = self.preprocess_image(image_path)
        
        # Make prediction
        predictions = self.model.predict(processed_img, verbose=0)
        
        # Get predicted class and confidence
        predicted_class_idx = np.argmax(predictions[0])
        confidence = np.max(predictions[0])
        
        # Get class name
        if self.label_encoder is not None:
            predicted_class = self.label_encoder.inverse_transform([predicted_class_idx])[0]
        else:
            predicted_class = DISEASE_CLASSES[predicted_class_idx]
        
        # Prepare result
        result = {
            'predicted_class': predicted_class,
            'confidence': float(confidence),
            'predicted_class_index': int(predicted_class_idx)
        }
        
        if return_all_probabilities:
            if self.label_encoder is not None:
                class_names = self.label_encoder.classes_
            else:
                class_names = DISEASE_CLASSES
            
            result['all_probabilities'] = {
                class_name: float(prob) 
                for class_name, prob in zip(class_names, predictions[0])
            }
        
        return result
    
    def predict_batch(self, image_paths, batch_size=32):
        """Predict diseases for multiple images"""
        print(f"🔍 Analyzing {len(image_paths)} images...")
        
        results = []
        
        for i in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[i:i + batch_size]
            batch_images = []
            
            # Preprocess batch
            for img_path in batch_paths:
                try:
                    processed_img = self.preprocess_image(img_path)
                    batch_images.append(processed_img[0])  # Remove batch dimension
                except Exception as e:
                    print(f"❌ Error processing {img_path}: {e}")
                    continue
            
            if not batch_images:
                continue
            
            # Convert to numpy array
            batch_array = np.array(batch_images)
            
            # Make predictions
            predictions = self.model.predict(batch_array, verbose=0)
            
            # Process results
            for j, (img_path, pred) in enumerate(zip(batch_paths, predictions)):
                predicted_class_idx = np.argmax(pred)
                confidence = np.max(pred)
                
                if self.label_encoder is not None:
                    predicted_class = self.label_encoder.inverse_transform([predicted_class_idx])[0]
                else:
                    predicted_class = DISEASE_CLASSES[predicted_class_idx]
                
                results.append({
                    'image_path': str(img_path),
                    'predicted_class': predicted_class,
                    'confidence': float(confidence),
                    'predicted_class_index': int(predicted_class_idx)
                })
        
        return results
    
    def visualize_prediction(self, image_path, save_path=None):
        """Visualize prediction with image and results"""
        # Make prediction
        result = self.predict(image_path, return_all_probabilities=True)
        
        # Load and display image
        img = cv2.imread(str(image_path))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Create visualization
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        
        # Display image
        axes[0].imshow(img)
        axes[0].set_title(f'Chest X-Ray\n{Path(image_path).name}')
        axes[0].axis('off')
        
        # Display prediction results
        if 'all_probabilities' in result:
            classes = list(result['all_probabilities'].keys())
            probabilities = list(result['all_probabilities'].values())
            
            # Sort by probability
            sorted_indices = np.argsort(probabilities)[::-1]
            classes = [classes[i] for i in sorted_indices]
            probabilities = [probabilities[i] for i in sorted_indices]
            
            # Create bar plot
            colors = ['red' if i == 0 else 'lightblue' for i in range(len(classes))]
            bars = axes[1].barh(classes, probabilities, color=colors, alpha=0.7)
            
            axes[1].set_xlabel('Probability')
            axes[1].set_title(f'Prediction Results\nTop Prediction: {result["predicted_class"]}\nConfidence: {result["confidence"]:.3f}')
            axes[1].set_xlim(0, 1)
            
            # Add probability labels
            for bar, prob in zip(bars, probabilities):
                axes[1].text(bar.get_width() + 0.01, bar.get_y() + bar.get_height()/2, 
                           f'{prob:.3f}', va='center', ha='left')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"💾 Visualization saved to {save_path}")
        
        plt.show()
        
        return result
    
    def generate_prediction_report(self, image_paths, output_path=None):
        """Generate a comprehensive prediction report"""
        print("📊 Generating prediction report...")
        
        # Make predictions
        results = self.predict_batch(image_paths)
        
        # Analyze results
        class_counts = {}
        confidence_stats = {}
        
        for result in results:
            pred_class = result['predicted_class']
            confidence = result['confidence']
            
            # Count predictions per class
            class_counts[pred_class] = class_counts.get(pred_class, 0) + 1
            
            # Collect confidence statistics
            if pred_class not in confidence_stats:
                confidence_stats[pred_class] = []
            confidence_stats[pred_class].append(confidence)
        
        # Calculate statistics
        for class_name in confidence_stats:
            confidences = confidence_stats[class_name]
            confidence_stats[class_name] = {
                'count': len(confidences),
                'mean_confidence': np.mean(confidences),
                'std_confidence': np.std(confidences),
                'min_confidence': np.min(confidences),
                'max_confidence': np.max(confidences)
            }
        
        # Create report
        report = {
            'total_images': len(results),
            'predictions_by_class': class_counts,
            'confidence_statistics': confidence_stats,
            'detailed_results': results
        }
        
        # Save report
        if output_path is None:
            output_path = "ML_Implementation/inference/prediction_report.json"
        
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"✅ Report saved to {output_path}")
        
        # Create visualization
        self._visualize_report(report, str(Path(output_path).with_suffix('.png')))
        
        return report
    
    def _visualize_report(self, report, save_path):
        """Create visualization for prediction report"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Class distribution
        classes = list(report['predictions_by_class'].keys())
        counts = list(report['predictions_by_class'].values())
        
        axes[0, 0].bar(classes, counts, color='skyblue', alpha=0.7)
        axes[0, 0].set_title('Predictions by Disease Class')
        axes[0, 0].set_xlabel('Disease Class')
        axes[0, 0].set_ylabel('Number of Predictions')
        axes[0, 0].tick_params(axis='x', rotation=45)
        
        # Confidence distribution
        all_confidences = [result['confidence'] for result in report['detailed_results']]
        axes[0, 1].hist(all_confidences, bins=20, color='lightgreen', alpha=0.7, edgecolor='black')
        axes[0, 1].set_title('Confidence Score Distribution')
        axes[0, 1].set_xlabel('Confidence Score')
        axes[0, 1].set_ylabel('Frequency')
        
        # Mean confidence by class
        conf_stats = report['confidence_statistics']
        classes_with_stats = list(conf_stats.keys())
        mean_confidences = [conf_stats[cls]['mean_confidence'] for cls in classes_with_stats]
        
        axes[1, 0].bar(classes_with_stats, mean_confidences, color='orange', alpha=0.7)
        axes[1, 0].set_title('Mean Confidence by Class')
        axes[1, 0].set_xlabel('Disease Class')
        axes[1, 0].set_ylabel('Mean Confidence')
        axes[1, 0].tick_params(axis='x', rotation=45)
        
        # Summary statistics
        axes[1, 1].axis('off')
        summary_text = f"""
        Prediction Summary
        
        Total Images: {report['total_images']}
        
        Most Common Prediction: {max(report['predictions_by_class'], key=report['predictions_by_class'].get)}
        
        Overall Mean Confidence: {np.mean(all_confidences):.3f}
        
        High Confidence Predictions (>0.9): {sum(1 for c in all_confidences if c > 0.9)}
        
        Low Confidence Predictions (<0.5): {sum(1 for c in all_confidences if c < 0.5)}
        """
        
        axes[1, 1].text(0.1, 0.9, summary_text, transform=axes[1, 1].transAxes, 
                        fontsize=12, verticalalignment='top', fontfamily='monospace')
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()

def main():
    """Main function for image prediction"""
    print("🚀 Lung Disease Image Prediction")
    
    try:
        # Initialize predictor
        predictor = LungDiseasePredictor()
        
        # Example usage
        print("\nChoose an option:")
        print("1. Predict single image")
        print("2. Predict batch of images")
        print("3. Generate prediction report")
        
        choice = input("Enter choice (1-3): ").strip()
        
        if choice == "1":
            image_path = input("Enter image path: ").strip()
            if Path(image_path).exists():
                result = predictor.visualize_prediction(image_path)
                print(f"\nPrediction: {result['predicted_class']}")
                print(f"Confidence: {result['confidence']:.3f}")
            else:
                print("❌ Image file not found")
        
        elif choice == "2":
            folder_path = input("Enter folder path containing images: ").strip()
            folder = Path(folder_path)
            if folder.exists():
                image_paths = list(folder.glob("*.jpg")) + list(folder.glob("*.png")) + list(folder.glob("*.jpeg"))
                if image_paths:
                    results = predictor.predict_batch(image_paths)
                    print(f"\n✅ Processed {len(results)} images")
                    for result in results[:5]:  # Show first 5 results
                        print(f"{Path(result['image_path']).name}: {result['predicted_class']} ({result['confidence']:.3f})")
                else:
                    print("❌ No image files found in folder")
            else:
                print("❌ Folder not found")
        
        elif choice == "3":
            folder_path = input("Enter folder path containing images: ").strip()
            folder = Path(folder_path)
            if folder.exists():
                image_paths = list(folder.glob("*.jpg")) + list(folder.glob("*.png")) + list(folder.glob("*.jpeg"))
                if image_paths:
                    report = predictor.generate_prediction_report(image_paths)
                    print("✅ Prediction report generated")
                else:
                    print("❌ No image files found in folder")
            else:
                print("❌ Folder not found")
        
        else:
            print("❌ Invalid choice")
    
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
