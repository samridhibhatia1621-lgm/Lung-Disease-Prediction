"""
Training script for the lung disease classifier
Trains the deep learning model for multi-class disease classification
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import json
import sys
sys.path.append(str(Path(__file__).parent.parent))

from models.classifier import LungDiseaseClassifier
from config import CLASSIFIER_CONFIG, DATASET_CONFIG, DISEASE_CLASSES
import joblib

def load_processed_data():
    """Load preprocessed data"""
    processed_data_path = DATASET_CONFIG["processed_data_path"]
    
    print("📂 Loading processed data...")
    
    # Load training data
    X_train = np.load(processed_data_path / "train" / "X.npy")
    y_train = np.load(processed_data_path / "train" / "y.npy")
    
    # Load validation data
    X_val = np.load(processed_data_path / "val" / "X.npy")
    y_val = np.load(processed_data_path / "val" / "y.npy")
    
    # Load test data
    X_test = np.load(processed_data_path / "test" / "X.npy")
    y_test = np.load(processed_data_path / "test" / "y.npy")
    
    print(f"✅ Data loaded successfully")
    print(f"Training set: {X_train.shape}")
    print(f"Validation set: {X_val.shape}")
    print(f"Test set: {X_test.shape}")
    
    return (X_train, y_train), (X_val, y_val), (X_test, y_test)

def load_augmented_data():
    """Load augmented data if available"""
    augmented_path = DATASET_CONFIG["augmented_data_path"]
    
    if not augmented_path.exists():
        print("⚠️  No augmented data found. Using original data only.")
        return None, None
    
    print("📂 Loading augmented data...")
    
    try:
        X_aug = np.load(augmented_path / "X_augmented.npy")
        y_aug = np.load(augmented_path / "y_augmented.npy")
        
        print(f"✅ Augmented data loaded: {X_aug.shape}")
        return X_aug, y_aug
    except FileNotFoundError:
        print("⚠️  Augmented data files not found.")
        return None, None

def combine_datasets(X_train, y_train, X_aug=None, y_aug=None):
    """Combine original and augmented datasets"""
    if X_aug is not None and y_aug is not None:
        print("🔄 Combining original and augmented data...")
        
        X_combined = np.concatenate([X_train, X_aug], axis=0)
        y_combined = np.concatenate([y_train, y_aug], axis=0)
        
        print(f"Combined dataset size: {X_combined.shape}")
        return X_combined, y_combined
    else:
        return X_train, y_train

def analyze_class_distribution(y_train, y_val, y_test):
    """Analyze and visualize class distribution"""
    print("📊 Analyzing class distribution...")
    
    # Load label encoder
    label_encoder = joblib.load(DATASET_CONFIG["processed_data_path"] / "label_encoder.pkl")
    
    # Convert encoded labels back to class names
    y_train_labels = label_encoder.inverse_transform(y_train)
    y_val_labels = label_encoder.inverse_transform(y_val)
    y_test_labels = label_encoder.inverse_transform(y_test)
    
    # Count classes
    train_counts = {cls: np.sum(y_train_labels == cls) for cls in DISEASE_CLASSES}
    val_counts = {cls: np.sum(y_val_labels == cls) for cls in DISEASE_CLASSES}
    test_counts = {cls: np.sum(y_test_labels == cls) for cls in DISEASE_CLASSES}
    
    # Create visualization
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    datasets = [('Training', train_counts), ('Validation', val_counts), ('Test', test_counts)]
    
    for idx, (name, counts) in enumerate(datasets):
        classes = list(counts.keys())
        values = list(counts.values())
        
        axes[idx].bar(classes, values, color='skyblue', alpha=0.7)
        axes[idx].set_title(f'{name} Set Distribution')
        axes[idx].set_xlabel('Disease Class')
        axes[idx].set_ylabel('Number of Images')
        axes[idx].tick_params(axis='x', rotation=45)
        
        # Add value labels on bars
        for i, v in enumerate(values):
            axes[idx].text(i, v + max(values) * 0.01, str(v), ha='center', va='bottom')
    
    plt.tight_layout()
    plt.savefig("ML_Implementation/models/class_distribution.png", dpi=300, bbox_inches='tight')
    plt.show()
    
    return train_counts, val_counts, test_counts

def train_model(model_name=None):
    """Train the classification model"""
    if model_name is None:
        model_name = CLASSIFIER_CONFIG["model_name"]
    
    print(f"🚀 Starting training with {model_name}...")
    
    # Load data
    (X_train, y_train), (X_val, y_val), (X_test, y_test) = load_processed_data()
    
    # Load augmented data
    X_aug, y_aug = load_augmented_data()
    
    # Combine datasets
    X_train, y_train = combine_datasets(X_train, y_train, X_aug, y_aug)
    
    # Analyze class distribution
    analyze_class_distribution(y_train, y_val, y_test)
    
    # Initialize classifier
    classifier = LungDiseaseClassifier()
    
    # Build model
    classifier.build_model(model_name)
    classifier.compile_model()
    
    # Train model
    history = classifier.train(X_train, y_train, X_val, y_val)
    
    # Fine-tune model
    print("\n🔧 Starting fine-tuning...")
    fine_tune_history = classifier.fine_tune(X_train, y_train, X_val, y_val, fine_tune_epochs=10)
    
    # Evaluate model
    print("\n📊 Evaluating model...")
    evaluation_results = classifier.evaluate(X_test, y_test)
    
    # Plot results
    classifier.plot_training_history()
    classifier.plot_confusion_matrix(evaluation_results['confusion_matrix'])
    
    # Save model
    classifier.save_model()
    
    # Save evaluation results
    save_evaluation_results(evaluation_results, model_name)
    
    print("✅ Training completed successfully!")
    return classifier, evaluation_results

def save_evaluation_results(results, model_name):
    """Save evaluation results to file"""
    print("💾 Saving evaluation results...")
    
    # Convert numpy arrays to lists for JSON serialization
    results_serializable = {
        'model_name': model_name,
        'test_accuracy': float(results['test_accuracy']),
        'test_loss': float(results['test_loss']),
        'classification_report': results['classification_report'],
        'confusion_matrix': results['confusion_matrix'].tolist(),
        'disease_classes': DISEASE_CLASSES
    }
    
    # Save to JSON
    with open("ML_Implementation/models/evaluation_results.json", 'w') as f:
        json.dump(results_serializable, f, indent=2)
    
    # Create detailed report
    create_detailed_report(results, model_name)
    
    print("✅ Evaluation results saved")

def create_detailed_report(results, model_name):
    """Create a detailed evaluation report"""
    report = f"""
# Lung Disease Classification Model Evaluation Report

## Model Information
- **Model Architecture**: {model_name}
- **Number of Classes**: {len(DISEASE_CLASSES)}
- **Disease Classes**: {', '.join(DISEASE_CLASSES)}

## Overall Performance
- **Test Accuracy**: {results['test_accuracy']:.4f} ({results['test_accuracy']*100:.2f}%)
- **Test Loss**: {results['test_loss']:.4f}

## Per-Class Performance

| Disease Class | Precision | Recall | F1-Score | Support |
|---------------|-----------|--------|----------|---------|
"""
    
    classification_report = results['classification_report']
    
    for disease in DISEASE_CLASSES:
        if disease in classification_report:
            metrics = classification_report[disease]
            report += f"| {disease} | {metrics['precision']:.3f} | {metrics['recall']:.3f} | {metrics['f1-score']:.3f} | {metrics['support']} |\n"
    
    # Add macro and weighted averages
    if 'macro avg' in classification_report:
        macro_avg = classification_report['macro avg']
        report += f"| **Macro Average** | {macro_avg['precision']:.3f} | {macro_avg['recall']:.3f} | {macro_avg['f1-score']:.3f} | {macro_avg['support']} |\n"
    
    if 'weighted avg' in classification_report:
        weighted_avg = classification_report['weighted avg']
        report += f"| **Weighted Average** | {weighted_avg['precision']:.3f} | {weighted_avg['recall']:.3f} | {weighted_avg['f1-score']:.3f} | {weighted_avg['support']} |\n"
    
    report += f"""
## Confusion Matrix Analysis

The confusion matrix shows the model's performance across all classes:

```
Predicted →
Actual ↓    {' '.join([f'{cls[:4]:>6}' for cls in DISEASE_CLASSES])}
"""
    
    cm = results['confusion_matrix']
    for i, disease in enumerate(DISEASE_CLASSES):
        row = f"{disease[:4]:>10}    "
        for j in range(len(DISEASE_CLASSES)):
            row += f"{cm[i][j]:>6} "
        report += row + "\n"
    
    report += "```\n"
    
    # Save report
    with open("ML_Implementation/models/evaluation_report.md", 'w') as f:
        f.write(report)

def compare_models():
    """Compare different model architectures"""
    print("🔄 Comparing different model architectures...")
    
    models_to_test = ["efficientnet_b0", "resnet50", "densenet121"]
    results_comparison = {}
    
    for model_name in models_to_test:
        print(f"\n{'='*50}")
        print(f"TRAINING {model_name.upper()}")
        print(f"{'='*50}")
        
        try:
            classifier, results = train_model(model_name)
            results_comparison[model_name] = {
                'accuracy': results['test_accuracy'],
                'loss': results['test_loss'],
                'classification_report': results['classification_report']
            }
        except Exception as e:
            print(f"❌ Error training {model_name}: {e}")
            continue
    
    # Save comparison results
    with open("ML_Implementation/models/model_comparison.json", 'w') as f:
        json.dump(results_comparison, f, indent=2)
    
    # Create comparison visualization
    create_model_comparison_plot(results_comparison)
    
    return results_comparison

def create_model_comparison_plot(results_comparison):
    """Create visualization comparing different models"""
    if not results_comparison:
        return
    
    models = list(results_comparison.keys())
    accuracies = [results_comparison[model]['accuracy'] for model in models]
    losses = [results_comparison[model]['loss'] for model in models]
    
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    
    # Accuracy comparison
    axes[0].bar(models, accuracies, color='lightblue', alpha=0.7)
    axes[0].set_title('Model Accuracy Comparison')
    axes[0].set_ylabel('Test Accuracy')
    axes[0].set_ylim(0, 1)
    
    # Add value labels
    for i, acc in enumerate(accuracies):
        axes[0].text(i, acc + 0.01, f'{acc:.3f}', ha='center', va='bottom')
    
    # Loss comparison
    axes[1].bar(models, losses, color='lightcoral', alpha=0.7)
    axes[1].set_title('Model Loss Comparison')
    axes[1].set_ylabel('Test Loss')
    
    # Add value labels
    for i, loss in enumerate(losses):
        axes[1].text(i, loss + max(losses) * 0.01, f'{loss:.3f}', ha='center', va='bottom')
    
    plt.tight_layout()
    plt.savefig("ML_Implementation/models/model_comparison.png", dpi=300, bbox_inches='tight')
    plt.show()

def main():
    """Main training function"""
    print("🚀 Starting Classifier Training Pipeline...")
    
    try:
        # Create necessary directories
        Path("ML_Implementation/models").mkdir(exist_ok=True)
        Path("ML_Implementation/logs").mkdir(exist_ok=True)
        
        # Train single model or compare multiple models
        choice = input("Train single model (s) or compare multiple models (m)? [s/m]: ").lower()
        
        if choice == 'm':
            results_comparison = compare_models()
            print("\n🎉 Model comparison completed!")
            
            # Show best model
            if results_comparison:
                best_model = max(results_comparison.keys(), 
                               key=lambda x: results_comparison[x]['accuracy'])
                best_accuracy = results_comparison[best_model]['accuracy']
                print(f"🏆 Best model: {best_model} (Accuracy: {best_accuracy:.4f})")
        else:
            classifier, results = train_model()
            print(f"\n🎉 Training completed!")
            print(f"Final test accuracy: {results['test_accuracy']:.4f}")
        
        print("\nNext steps:")
        print("1. Run: python inference/predict_image.py")
        print("2. Run: python inference/predict_symptoms.py")
        print("3. Deploy the model to production")
        
    except Exception as e:
        print(f"❌ Error during training: {e}")
        raise

if __name__ == "__main__":
    main()
