"""
Training script for GAN model
Trains the Generative Adversarial Network for data augmentation
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import json
import sys
sys.path.append(str(Path(__file__).parent.parent))

from models.gan_model import ChestXrayGAN, ConditionalGAN
from config import GAN_CONFIG, DATASET_CONFIG
import joblib

def load_training_data():
    """Load preprocessed training data"""
    processed_data_path = DATASET_CONFIG["processed_data_path"]
    
    print("📂 Loading training data...")
    
    # Load training data
    X_train = np.load(processed_data_path / "train" / "X.npy")
    y_train = np.load(processed_data_path / "train" / "y.npy")
    
    print(f"✅ Loaded {len(X_train)} training images")
    print(f"Image shape: {X_train.shape[1:]}")
    
    return X_train, y_train

def train_standard_gan():
    """Train standard GAN model"""
    print("🚀 Starting Standard GAN Training...")
    
    # Load data
    X_train, _ = load_training_data()
    
    # Initialize GAN
    gan = ChestXrayGAN()
    gan.build_gan()
    
    # Train GAN
    history = gan.train(
        X_train,
        epochs=GAN_CONFIG["epochs"],
        batch_size=GAN_CONFIG["batch_size"],
        save_interval=GAN_CONFIG["save_interval"]
    )
    
    # Save final models
    gan.save_final_models()
    
    # Save training history
    with open("ML_Implementation/models/gan_training_history.json", 'w') as f:
        json.dump(history, f, indent=2)
    
    # Plot training history
    plot_gan_history(history)
    
    print("✅ Standard GAN training completed!")
    return gan, history

def train_conditional_gan():
    """Train conditional GAN model"""
    print("🚀 Starting Conditional GAN Training...")
    
    # Load data
    X_train, y_train = load_training_data()
    
    # Initialize Conditional GAN
    cgan = ConditionalGAN()
    cgan.generator = cgan.build_conditional_generator()
    cgan.discriminator = cgan.build_conditional_discriminator()
    
    # Compile models
    cgan.discriminator.compile(
        optimizer='adam',
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    
    # Build combined model
    cgan.discriminator.trainable = False
    noise_input = cgan.generator.input[0]
    label_input = cgan.generator.input[1]
    generated_img = cgan.generator([noise_input, label_input])
    validity = cgan.discriminator([generated_img, label_input])
    
    from tensorflow import keras
    cgan.gan = keras.Model([noise_input, label_input], validity)
    cgan.gan.compile(optimizer='adam', loss='binary_crossentropy')
    
    # Train conditional GAN
    history = train_conditional_gan_loop(cgan, X_train, y_train)
    
    # Save models
    cgan.generator.save("ML_Implementation/models/conditional_generator.h5")
    cgan.discriminator.save("ML_Implementation/models/conditional_discriminator.h5")
    
    print("✅ Conditional GAN training completed!")
    return cgan, history

def train_conditional_gan_loop(cgan, X_train, y_train):
    """Training loop for conditional GAN"""
    epochs = GAN_CONFIG["epochs"]
    batch_size = GAN_CONFIG["batch_size"]
    
    # Normalize data
    X_train = (X_train - 0.5) * 2.0
    
    history = {
        'discriminator_loss': [],
        'generator_loss': []
    }
    
    for epoch in range(epochs):
        # Train discriminator
        idx = np.random.randint(0, X_train.shape[0], batch_size)
        real_imgs = X_train[idx]
        real_labels = y_train[idx]
        
        # Generate fake images
        noise = np.random.normal(0, 1, (batch_size, cgan.latent_dim))
        fake_labels = np.random.randint(0, cgan.num_classes, batch_size)
        fake_imgs = cgan.generator.predict([noise, fake_labels], verbose=0)
        
        # Train discriminator
        d_loss_real = cgan.discriminator.train_on_batch([real_imgs, real_labels], np.ones((batch_size, 1)))
        d_loss_fake = cgan.discriminator.train_on_batch([fake_imgs, fake_labels], np.zeros((batch_size, 1)))
        d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)
        
        # Train generator
        noise = np.random.normal(0, 1, (batch_size, cgan.latent_dim))
        gen_labels = np.random.randint(0, cgan.num_classes, batch_size)
        g_loss = cgan.gan.train_on_batch([noise, gen_labels], np.ones((batch_size, 1)))
        
        # Record history
        history['discriminator_loss'].append(float(d_loss[0]))
        history['generator_loss'].append(float(g_loss))
        
        # Print progress
        if epoch % 10 == 0:
            print(f"Epoch {epoch}/{epochs} - D_loss: {d_loss[0]:.4f}, G_loss: {g_loss:.4f}")
        
        # Save sample images
        if epoch % GAN_CONFIG["sample_interval"] == 0:
            save_conditional_samples(cgan, epoch)
    
    return history

def save_conditional_samples(cgan, epoch):
    """Save sample images from conditional GAN"""
    noise = np.random.normal(0, 1, (cgan.num_classes, cgan.latent_dim))
    labels = np.arange(cgan.num_classes)
    
    generated_imgs = cgan.generator.predict([noise, labels], verbose=0)
    generated_imgs = (generated_imgs + 1) / 2.0
    
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    axes = axes.flatten()
    
    from config import DISEASE_CLASSES
    
    for i in range(min(len(generated_imgs), 6)):
        axes[i].imshow(generated_imgs[i])
        axes[i].set_title(f'{DISEASE_CLASSES[i]}')
        axes[i].axis('off')
    
    plt.tight_layout()
    
    samples_dir = Path("ML_Implementation/models/conditional_samples")
    samples_dir.mkdir(exist_ok=True)
    plt.savefig(samples_dir / f"conditional_epoch_{epoch}.png", dpi=150, bbox_inches='tight')
    plt.close()

def plot_gan_history(history):
    """Plot GAN training history"""
    fig, axes = plt.subplots(1, 2, figsize=(15, 5))
    
    # Discriminator loss and accuracy
    axes[0].plot(history['discriminator_loss'], label='Discriminator Loss', color='red')
    axes[0].set_title('Discriminator Loss')
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss')
    axes[0].legend()
    axes[0].grid(True)
    
    if 'discriminator_accuracy' in history:
        ax0_twin = axes[0].twinx()
        ax0_twin.plot(history['discriminator_accuracy'], label='Discriminator Accuracy', color='blue', alpha=0.7)
        ax0_twin.set_ylabel('Accuracy')
        ax0_twin.legend(loc='upper right')
    
    # Generator loss
    axes[1].plot(history['generator_loss'], label='Generator Loss', color='green')
    axes[1].set_title('Generator Loss')
    axes[1].set_xlabel('Epoch')
    axes[1].set_ylabel('Loss')
    axes[1].legend()
    axes[1].grid(True)
    
    plt.tight_layout()
    plt.savefig("ML_Implementation/models/gan_training_history.png", dpi=300, bbox_inches='tight')
    plt.show()

def generate_sample_images(num_samples=100):
    """Generate sample images using trained GAN"""
    print(f"🎨 Generating {num_samples} sample images...")
    
    # Load trained generator
    from tensorflow import keras
    generator_path = "ML_Implementation/models/gan_generator.h5"
    
    if not Path(generator_path).exists():
        print("❌ Trained generator not found. Train GAN first.")
        return
    
    generator = keras.models.load_model(generator_path)
    
    # Generate images
    noise = np.random.normal(0, 1, (num_samples, GAN_CONFIG["latent_dim"]))
    generated_imgs = generator.predict(noise, verbose=0)
    
    # Rescale to [0, 1]
    generated_imgs = (generated_imgs + 1) / 2.0
    
    # Save generated images
    output_dir = Path("ML_Implementation/data/generated")
    output_dir.mkdir(exist_ok=True)
    
    for i, img in enumerate(generated_imgs):
        img_uint8 = (img * 255).astype(np.uint8)
        plt.imsave(output_dir / f"generated_{i:04d}.png", img_uint8)
    
    print(f"✅ Generated images saved to {output_dir}")

def main():
    """Main training function"""
    print("🚀 Starting GAN Training Pipeline...")
    
    try:
        # Create necessary directories
        Path("ML_Implementation/models").mkdir(exist_ok=True)
        Path("ML_Implementation/logs").mkdir(exist_ok=True)
        
        # Train standard GAN
        print("\n" + "="*50)
        print("TRAINING STANDARD GAN")
        print("="*50)
        
        gan, history = train_standard_gan()
        
        # Optionally train conditional GAN
        print("\n" + "="*50)
        print("TRAINING CONDITIONAL GAN")
        print("="*50)
        
        cgan, cgan_history = train_conditional_gan()
        
        # Generate sample images
        generate_sample_images(100)
        
        print("\n🎉 GAN training pipeline completed successfully!")
        print("Next steps:")
        print("1. Run: python data/augmentation.py")
        print("2. Run: python training/train_classifier.py")
        
    except Exception as e:
        print(f"❌ Error during GAN training: {e}")
        raise

if __name__ == "__main__":
    main()
