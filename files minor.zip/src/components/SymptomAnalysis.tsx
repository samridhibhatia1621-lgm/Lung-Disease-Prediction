import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function SymptomAnalysis() {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const availableSymptoms = (useQuery(api.symptoms.getAvailableSymptoms) || []) as string[];
  const analyzeSymptoms = useQuery(
    api.symptoms.analyzeSymptoms,
    selectedSymptoms.length > 0 ? { symptoms: selectedSymptoms } : "skip"
  );
  const savePrediction = useMutation(api.predictions.savePrediction);

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptom)
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
    setResult(null);
  };

  const performAnalysis = async () => {
    if (selectedSymptoms.length === 0) {
      toast.error("Please select at least one symptom");
      return;
    }

    setIsAnalyzing(true);
    
    try {
      // Wait for analysis to complete
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      if (analyzeSymptoms) {
        const topResult = analyzeSymptoms.results[0];
        
        if (topResult) {
          await savePrediction({
            type: "symptoms",
            symptoms: selectedSymptoms,
            prediction: topResult.disease,
            confidence: topResult.confidence / 100,
            recommendations: analyzeSymptoms.recommendations,
          });
        }

        setResult(analyzeSymptoms);
        toast.success("Symptom analysis completed!");
      }
    } catch (error) {
      console.error("Analysis failed:", error);
      toast.error("Failed to analyze symptoms. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetAnalysis = () => {
    setSelectedSymptoms([]);
    setResult(null);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "mild": return "text-green-600 bg-green-50 border-green-200";
      case "moderate": return "text-yellow-600 bg-yellow-50 border-yellow-200";
      case "severe": return "text-red-600 bg-red-50 border-red-200";
      default: return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">Symptom-Based Analysis</h3>

      <div className="space-y-6">
        {/* Symptom Selection */}
        <div>
          <p className="text-sm font-medium text-gray-700 mb-3">
            Select your symptoms (choose all that apply):
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {availableSymptoms.map((symptom) => (
              <button
                key={symptom}
                onClick={() => toggleSymptom(symptom)}
                className={`p-3 text-sm rounded-lg border transition-colors text-left ${
                  selectedSymptoms.includes(symptom)
                    ? "bg-blue-50 border-blue-300 text-blue-700"
                    : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                }`}
              >
                {symptom}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Symptoms */}
        {selectedSymptoms.length > 0 && (
          <div className="bg-blue-50 rounded-lg p-4">
            <p className="text-sm font-medium text-blue-900 mb-2">
              Selected Symptoms ({selectedSymptoms.length}):
            </p>
            <div className="flex flex-wrap gap-2">
              {selectedSymptoms.map((symptom) => (
                <span
                  key={symptom}
                  className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center"
                >
                  {symptom}
                  <button
                    onClick={() => toggleSymptom(symptom)}
                    className="ml-2 text-blue-600 hover:text-blue-800"
                  >
                    ✕
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Analysis Button */}
        <div className="flex space-x-3">
          <button
            onClick={performAnalysis}
            disabled={selectedSymptoms.length === 0 || isAnalyzing}
            className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isAnalyzing ? (
              <span className="flex items-center justify-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Analyzing...</span>
              </span>
            ) : (
              "Analyze Symptoms"
            )}
          </button>
          
          {selectedSymptoms.length > 0 && (
            <button
              onClick={resetAnalysis}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Reset
            </button>
          )}
        </div>

        {/* Enhanced Results */}
        {result && (
          <div className="bg-gray-50 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold text-gray-900">Analysis Results</h4>
              <div className="text-xs text-gray-500">
                {result.totalMatches} condition{result.totalMatches !== 1 ? 's' : ''} found
              </div>
            </div>
            
            {result.hasEmergencySymptoms && (
              <div className="bg-red-100 border-2 border-red-300 rounded-lg p-4 mb-4">
                <p className="text-red-900 font-bold text-lg">🚨 EMERGENCY ALERT</p>
                <p className="text-red-800 text-sm mt-1">Your symptoms may indicate a medical emergency. Call 911 or go to the emergency room immediately.</p>
              </div>
            )}

            {result.hasHighRiskSymptoms && !result.hasEmergencySymptoms && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                <p className="text-red-800 font-medium">⚠️ High-risk symptoms detected</p>
                <p className="text-red-700 text-sm mt-1">Please seek immediate medical attention</p>
              </div>
            )}

            {result.results.length > 0 ? (
              <div className="space-y-6">
                <div>
                  <p className="font-medium text-gray-900 mb-3">
                    Possible Conditions (ranked by match confidence):
                  </p>
                  <div className="space-y-4">
                    {result.results.map((disease: any, index: number) => (
                      <div key={index} className="bg-white rounded-lg border p-5 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <h5 className="font-semibold text-gray-900 text-lg">{disease.disease}</h5>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(disease.severity)}`}>
                                {disease.severity}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mb-2">{disease.description}</p>
                          </div>
                          <div className="text-right ml-4">
                            <div className="text-2xl font-bold text-blue-600">{disease.confidence}%</div>
                            <div className="text-xs text-gray-500">confidence</div>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                          <div>
                            <p className="text-xs font-medium text-gray-700 mb-1">Symptom Match:</p>
                            <div className="flex items-center space-x-2">
                              <div className="flex-1 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-blue-500 h-2 rounded-full" 
                                  style={{ width: `${(disease.matchingSymptoms / disease.totalSymptoms) * 100}%` }}
                                ></div>
                              </div>
                              <span className="text-xs text-gray-600">
                                {disease.matchingSymptoms}/{disease.totalSymptoms}
                              </span>
                            </div>
                          </div>
                          
                          {disease.treatment && (
                            <div>
                              <p className="text-xs font-medium text-gray-700 mb-1">Typical Treatment:</p>
                              <p className="text-xs text-gray-600">{disease.treatment}</p>
                            </div>
                          )}
                        </div>

                        {disease.urgency && (
                          <div className="mt-3 p-3 bg-gray-50 rounded-md">
                            <p className="text-xs font-medium text-gray-700 mb-1">Medical Urgency:</p>
                            <p className="text-sm text-gray-800">{disease.urgency}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-lg border p-5">
                  <div className="flex items-center space-x-2 mb-3">
                    <span className="text-lg">💡</span>
                    <p className="font-medium text-gray-900">Personalized Recommendations:</p>
                  </div>
                  <ul className="space-y-2">
                    {result.recommendations.map((rec: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start">
                        <span className="text-blue-500 mr-3 mt-0.5 font-bold">•</span>
                        <span className={rec.includes('🚨') || rec.includes('⚠️') ? 'font-semibold text-red-700' : ''}>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
                  <div className="flex items-start space-x-2">
                    <span className="text-blue-600 text-lg">ℹ️</span>
                    <div>
                      <p className="text-sm font-medium text-blue-900 mb-1">Analysis Summary</p>
                      <p className="text-xs text-blue-800">
                        Based on {selectedSymptoms.length} selected symptom{selectedSymptoms.length !== 1 ? 's' : ''}, 
                        we found {result.totalMatches} potential condition{result.totalMatches !== 1 ? 's' : ''} 
                        with varying confidence levels. This analysis is for informational purposes only.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-4xl mb-4">🔍</div>
                <p className="text-gray-500 text-lg mb-2">No significant matches found</p>
                <p className="text-sm text-gray-400 mb-4">
                  The selected symptoms don't strongly match our disease database.
                </p>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 max-w-md mx-auto">
                  <p className="text-sm text-yellow-800">
                    Consider consulting a healthcare provider if symptoms persist or worsen, 
                    even if no matches were found.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
