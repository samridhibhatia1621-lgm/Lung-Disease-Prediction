import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function PredictionHistory() {
  const predictions = useQuery(api.predictions.getUserPredictions) || [];

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "text-green-600 bg-green-50";
    if (confidence >= 0.6) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  if (predictions.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Prediction History</h3>
        <div className="text-center py-12">
          <div className="text-4xl mb-4">📋</div>
          <p className="text-gray-500 text-lg">No predictions yet</p>
          <p className="text-gray-400 text-sm mt-2">
            Upload an image or analyze symptoms to see your history here
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">Prediction History</h3>
      
      <div className="space-y-4">
        {predictions.map((prediction) => (
          <div key={prediction._id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  prediction.type === "image" ? "bg-blue-100 text-blue-600" : "bg-green-100 text-green-600"
                }`}>
                  {prediction.type === "image" ? "📸" : "🩺"}
                </div>
                <div>
                  <p className="font-medium text-gray-900">{prediction.prediction}</p>
                  <p className="text-sm text-gray-500">{formatDate(prediction.timestamp)}</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getConfidenceColor(prediction.confidence)}`}>
                {Math.round(prediction.confidence * 100)}%
              </span>
            </div>

            {prediction.imageUrl && (
              <div className="mb-3">
                <img
                  src={prediction.imageUrl}
                  alt="Analyzed X-ray"
                  className="w-24 h-24 object-cover rounded-lg border"
                />
              </div>
            )}

            {prediction.symptoms && prediction.symptoms.length > 0 && (
              <div className="mb-3">
                <p className="text-sm font-medium text-gray-700 mb-1">Symptoms:</p>
                <div className="flex flex-wrap gap-1">
                  {prediction.symptoms.map((symptom, index) => (
                    <span key={index} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                      {symptom}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Recommendations:</p>
              <ul className="text-sm text-gray-600 space-y-1">
                {prediction.recommendations.slice(0, 2).map((rec, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-blue-500 mr-2 mt-0.5">•</span>
                    {rec}
                  </li>
                ))}
                {prediction.recommendations.length > 2 && (
                  <li className="text-gray-400 text-xs">
                    +{prediction.recommendations.length - 2} more recommendations
                  </li>
                )}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
