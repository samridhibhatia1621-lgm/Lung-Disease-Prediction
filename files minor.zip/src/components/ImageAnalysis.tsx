import { useState, useRef } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function ImageAnalysis() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.predictions.generateUploadUrl);
  const savePrediction = useMutation(api.predictions.savePrediction);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setSelectedFile(file);
        const reader = new FileReader();
        reader.onload = (e) => setPreview(e.target?.result as string);
        reader.readAsDataURL(file);
        setResult(null);
      } else {
        toast.error("Please select a valid image file");
      }
    }
  };

  const analyzeImage = async () => {
    if (!selectedFile) return;

    setIsAnalyzing(true);
    try {
      // Upload image to Convex storage
      const uploadUrl = await generateUploadUrl();
      const uploadResult = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": selectedFile.type },
        body: selectedFile,
      });

      if (!uploadResult.ok) {
        throw new Error("Failed to upload image");
      }

      const { storageId } = await uploadResult.json();

      // Simulate AI analysis (replace with actual ML model inference)
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Mock prediction results
      const mockPredictions = [
        { disease: "Normal", confidence: 0.75 },
        { disease: "Pneumonia", confidence: 0.85 },
        { disease: "COVID-19", confidence: 0.92 },
        { disease: "Tuberculosis", confidence: 0.68 },
        { disease: "Lung Cancer", confidence: 0.45 },
      ];

      const randomPrediction = mockPredictions[Math.floor(Math.random() * mockPredictions.length)];
      
      const analysisResult = {
        prediction: randomPrediction.disease,
        confidence: randomPrediction.confidence,
        recommendations: generateRecommendations(randomPrediction.disease, randomPrediction.confidence)
      };

      // Save prediction to database
      await savePrediction({
        type: "image",
        imageStorageId: storageId,
        prediction: analysisResult.prediction,
        confidence: analysisResult.confidence,
        recommendations: analysisResult.recommendations,
      });

      setResult(analysisResult);
      toast.success("Image analysis completed!");

    } catch (error) {
      console.error("Analysis failed:", error);
      toast.error("Failed to analyze image. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generateRecommendations = (disease: string, confidence: number) => {
    const recommendations = [];
    
    if (disease === "Normal") {
      recommendations.push("No abnormalities detected in the chest X-ray");
      recommendations.push("Continue regular health check-ups");
    } else {
      if (confidence > 0.8) {
        recommendations.push("High confidence detection - seek immediate medical consultation");
        recommendations.push("Bring this analysis to your healthcare provider");
      } else if (confidence > 0.6) {
        recommendations.push("Moderate confidence - schedule a medical appointment");
        recommendations.push("Additional tests may be needed for confirmation");
      } else {
        recommendations.push("Low confidence - monitor symptoms and consult if they persist");
      }

      if (disease === "COVID-19") {
        recommendations.push("Consider COVID-19 testing and isolation if symptomatic");
      } else if (disease === "Tuberculosis") {
        recommendations.push("TB testing and contact tracing may be necessary");
      } else if (disease === "Lung Cancer") {
        recommendations.push("Urgent oncology consultation recommended");
      }
    }

    return recommendations;
  };

  const resetAnalysis = () => {
    setSelectedFile(null);
    setPreview(null);
    setResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">Chest X-Ray Analysis</h3>

      {!preview ? (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-400 transition-colors">
          <div className="space-y-4">
            <div className="text-4xl">📸</div>
            <div>
              <p className="text-lg font-medium text-gray-900">Upload Chest X-Ray</p>
              <p className="text-sm text-gray-500 mt-1">
                Supported formats: JPG, PNG, DICOM
              </p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Choose File
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="relative">
            <img
              src={preview}
              alt="Chest X-Ray"
              className="w-full max-w-md mx-auto rounded-lg shadow-sm border"
            />
            <button
              onClick={resetAnalysis}
              className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
            >
              ✕
            </button>
          </div>

          {!result && (
            <div className="text-center">
              <button
                onClick={analyzeImage}
                disabled={isAnalyzing}
                className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isAnalyzing ? (
                  <span className="flex items-center space-x-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Analyzing...</span>
                  </span>
                ) : (
                  "Analyze Image"
                )}
              </button>
            </div>
          )}

          {result && (
            <div className="bg-gray-50 rounded-lg p-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Analysis Results</h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-white rounded-lg border">
                  <div>
                    <p className="font-medium text-gray-900">Prediction</p>
                    <p className="text-lg font-bold text-blue-600">{result.prediction}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">Confidence</p>
                    <p className="text-lg font-bold">{Math.round(result.confidence * 100)}%</p>
                  </div>
                </div>

                <div className="bg-white rounded-lg border p-4">
                  <p className="font-medium text-gray-900 mb-2">Recommendations</p>
                  <ul className="space-y-1">
                    {result.recommendations.map((rec: string, index: number) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start">
                        <span className="text-blue-500 mr-2">•</span>
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
